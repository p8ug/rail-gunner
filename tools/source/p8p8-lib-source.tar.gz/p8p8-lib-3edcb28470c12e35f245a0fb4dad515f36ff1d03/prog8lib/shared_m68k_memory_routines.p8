sys {
    %option merge, ignore_unused

; ------- memory routines --------

    ; note: memcopy() is implemented differently for Amiga so it's not here in shared.

    asmsub memset(long mem @D0, uword numbytes @D1, ubyte value @D2) {
        %asm {{
            move.l   d3,-(sp)
            movea.l  d0,a0
            tst.w    d1
            beq      .done
            tst.b    d2
            beq      .do_clear       ; value==0: delegate to sys.memclear

            ; save fill byte zero-extended
            moveq    #0,d3
            move.b   d2,d3

            ; align address to even for word/longword transfers
            move.l   a0,d0
            btst     #0,d0
            beq      .aligned
            move.b   d3,(a0)+
            subq.l   #1,d1
            beq      .done

.aligned:
            ; expand fill byte to all byte positions in d3
            move.l   d3,d0
            lsl.l    #8,d0
            or.l     d0,d3
            move.l   d3,d0
            swap     d0
            or.l     d0,d3

            ; longword fill (4 bytes per iteration)
            moveq    #0,d0
            move.w   d1,d0           ; d0 = numbytes (zero-extended)
            lsr.l    #2,d0
            beq      .bytes
            subq.w   #1,d0
.loop_l:
            move.l   d3,(a0)+
            dbra     d0,.loop_l

            ; remaining bytes (0-3)
.bytes:
            and.w    #3,d1
            beq      .done
            subq.w   #1,d1
.loop_b:
            move.b   d3,(a0)+
            dbra     d1,.loop_b
            bra      .done
.do_clear:
            jsr      sys.memclear
.done:
            move.l   (sp)+,d3
            rts
        }}
    }

    asmsub memclear(long mem @D0, uword numbytes @D1) {
        ; Clear memory (fill with zero).  Uses movem.l d0-d7,-(a0)
        ; for the bulk clear (32 bytes per instruction, decrementing from
        ; the end address).  Handles misaligned start and remaining bytes.
        ; All instructions are plain 68000-compatible.
        %asm {{
            movem.l  d2-d7/a2-a4,-(sp)
            movea.l  d0,a0
            moveq    #0,d0
            move.w   d1,d0           ; d0 = numbytes (zero-extended)
            beq      .done

            ; align to even for word/longword access
            move.l   a0,d1
            btst     #0,d1
            beq      .compute
            clr.b    (a0)+
            subq.l   #1,d0
            beq      .done

.compute:
            move.l   d0,d1
            move.l   d1,d2
            and.w    #31,d2          ; d2 = tail bytes after 32-byte blocks
            lsr.l    #5,d1           ; d1 = number of 32-byte blocks
            move.l   d2,a2           ; a2 = tail bytes
            movea.l  d1,a1           ; a1 = block count (save before zeroing regs)

            ; point a0 past the last byte, so we can decrement with movem
            move.l   d1,d3
            lsl.l    #5,d3
            adda.l   d3,a0           ; a0 = end address
            movea.l  a0,a4           ; a4 = end address; the movem loop leaves a0 back at the start

            ; zero all data registers except d7 (d7 will be the loop counter, not in movem)
            move.l   d1,d7           ; d7 = block count (save before zeroing)
            moveq    #0,d0
            move.l   d0,d1
            move.l   d0,d2
            move.l   d0,d3
            move.l   d0,d4
            move.l   d0,d5
            move.l   d0,d6
            movea.l  d0,a1           ; also zero a1 (part of movem)

            ; bulk clear: 32 bytes per movem (d0-d6=28 bytes + a1=4 bytes), decrementing a0
            subq.w   #1,d7
            bmi      .tail
.loop_m:
            movem.l  d0-d6/a1,-(a0)
            dbra     d7,.loop_m

.tail:
            movea.l  a4,a0           ; a0 = end of the bulk region, where the tail bytes belong
            movea.l  a2,a3
            move.l   a3,d0           ; copy to data reg for shift/btst
            beq      .done
            move.l   d0,d1
            lsr.l    #2,d1           ; d1 = longwords in tail
            beq      .tail_words
            subq.l   #1,d1
.loop_l:
            clr.l    (a0)+
            subq.l   #1,d1
            bpl      .loop_l

.tail_words:
            btst     #1,d0
            beq      .tail_byte
            clr.w    (a0)+

.tail_byte:
            btst     #0,d0
            beq      .done
            clr.b    (a0)+
.done:
            movem.l  (sp)+,d2-d7/a2-a4
            rts
        }}
    }

    asmsub memsetw(long mem @D0, uword numwords @D1, uword value @D2) {
        ; Fill memory with the given 16-bit word value, for the given number of words.
        ; Requires word-aligned start address. Uses longword stores (2 words at a time)
        ; for the bulk fill, with a possible trailing single word.
        %asm {{
            movem.l  d2-d3,-(sp)
            movea.l  d0,a0
            moveq    #0,d0
            move.w   d1,d0           ; d0 = numwords (zero-extended)
            beq      .done
            move.w   d2,d1           ; d1 = fill word value

            ; Create longword fill pattern: d1:d1
            move.w   d1,d2
            swap     d2
            move.w   d1,d2           ; d2 = d1 : d1

            ; longword fill (2 words at a time)
            move.l   d0,d3
            lsr.l    #1,d3           ; d3 = numwords / 2
            beq      .odd_word
            subq.w   #1,d3
.loop_l:
            move.l   d2,(a0)+
            dbra     d3,.loop_l

.odd_word:
            btst     #0,d0
            beq      .done
            move.w   d1,(a0)+

.done:
            movem.l  (sp)+,d2-d3
            rts
        }}
    }

    asmsub memsetl(long mem @D0, uword numlongs @D1, long value @D2) {
        ; Fill memory with the given 32-bit longword value, for the given number of longwords.
        ; Requires longword-aligned start address. Uses longword stores.
        %asm {{
            movea.l  d0,a0
            moveq    #0,d0
            move.w   d1,d0           ; d0 = numlongs (zero-extended)
            beq      .done

            ; longword fill
            subq.w   #1,d0
.loop_l:
            move.l   d2,(a0)+
            dbra     d0,.loop_l

.done:
            rts
        }}
    }

}
