;
; module to parse the header data of a .wav file
; little-endian version for 16 bit 6502 cpus
;
; note: the sample rate in hz can be converted to a vera rate via:
;        vera_rate = (wavfile.sample_rate as long * 65536 / 25000000) as ubyte + 1
;        vera_rate_hz = (vera_rate as uword * 25000000 / 65536) as uword
;
;        or, the floating-point alternative:
;        const float vera_freq_factor = 25e6 / 65536.0
;        vera_rate = (wavfile.sample_rate as float / vera_freq_factor) + 1.0 as ubyte
;        vera_rate_hz = (vera_rate as float) * vera_freq_factor as uword
;

wavfile {
    %option ignore_unused

    enum Format {
        PCM        =  1,
        ADPCM      =  2,
        IEEE_FLOAT =  3,
        ALAW       =  6,
        MULAW      =  7,
        DVI_ADPCM  =  17,
    }

    uword sample_rate
    ubyte bits_per_sample
    uword data_offset
    ubyte wavefmt
    ubyte nchannels
    uword block_align
    long data_size

    sub parse_header(^^ubyte wav_data) -> bool {
        ; "RIFF" , filesize (int32) , "WAVE", "fmt ", fmtsize (int32)
        uword @zp header = wav_data
        if header[0]!=iso:'R' or header[1]!=iso:'I' or header[2]!=iso:'F' or header[3]!=iso:'F'
            or header[8]!=iso:'W' or header[9]!=iso:'A' or header[10]!=iso:'V' or header[11]!=iso:'E'
            or header[12]!=iso:'f' or header[13]!=iso:'m' or header[14]!=iso:'t' or header[15]!=iso:' ' {
            return false
        }
        ; uword filesize = peekw(header+4)
        uword chunksize = peekw(header+16)
        wavefmt = peek(header+20)
        nchannels = peek(header+22)
        sample_rate = peekw(header+24)    ; we assume sample rate <= 65535 so we can ignore the upper word
        block_align = peekw(header+32)
        bits_per_sample = peek(header+34)
        if wavefmt==Format::DVI_ADPCM or wavefmt==Format::ADPCM
            bits_per_sample *= 4

        ; skip chunks until we reach the 'data' chunk, but limit to avoid going of the end
        uword @zp offset = chunksize + 20
        repeat 20 {
            header += offset
            chunksize = peekw(header+4)        ; assume chunk size never exceeds 64kb so ignore upper word
            if header[0]==iso:'d' and header[1]==iso:'a' and header[2]==iso:'t' and header[3]==iso:'a' {
                data_size = mklong2(peekw(header+6), chunksize)
                data_offset = header + 8 - (wav_data as uword)
                return true
            }
            offset = 8 + chunksize
        }
        return false
    }
}
