; -- Word-sized arena / bump allocator for 6502 targets.
;    Manages one static memory slab at a time, provided by the caller via memory().
;    Calling init() again replaces the previously tracked slab.
;    Allocations are made by bumping a pointer forward. Individual
;    deallocations are not supported; use reset() to free everything at once.
;    Sizes are uword values and no even-address alignment is performed.

%option ignore_unused

arena {
    %option merge
    private pointer @shared base
    private pointer @shared next
    private pointer @shared end

    sub init(pointer base_addr, uword size) {
        ; -- initialize the arena over the range [base_addr, base_addr + size)
        base = base_addr
        next = base_addr
        end = base_addr + size
    }

    sub alloc(uword size) -> pointer {
        ; -- allocate size bytes from the arena. Returns 0 if the slab is exhausted.
        if size == 0
            return 0
        if next + size > end
            return 0
        pointer result = next
        next += size
        return result
    }

    sub reset() {
        ; -- reset the arena so the slab can be reused from the start
        next = base
    }
}
