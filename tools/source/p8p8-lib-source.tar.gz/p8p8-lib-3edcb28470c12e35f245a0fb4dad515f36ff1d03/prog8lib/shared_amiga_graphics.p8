;; Auto-generated from graphics_lib.sfd and graphics_lib.i
;; Library base: _GfxBase  in prog8: sys.GfxBase
;; Bank: 3
;; Functions: 163

%import custom
%import exec
%import utility

graphics {
    %option merge, no_symbol_prefixing

    ; Friendly aliases for the ViewPort.Modes bits from view.h.
    ; The NDK .i files only provide the V_-prefixed EQU variants
    ; (V_HIRES, V_LACE); these match the names used in C examples.
    const uword HIRES = $8000
    const uword LORES = 0
    const ubyte LACE = $0004
    const ubyte SUPERHIRES = $20

    sub load_palette(^^ViewPort vp, ^^long rgb24, uword count) {
        ; Canonical $00RRGGBB palette loader. Builds a LoadRGB32/LoadRGB4
        ; table in a static buffer and loads all entries in a single
        ; graphics.library call, instead of one SetRGB32/SetRGB4 per color.
        ; AGA: LoadRGB32 (V39+, 256 entries). ECS: LoadRGB4 (32 entries).
        if count == 0
            return
        if custom.detect_chipset()==custom.CHIPSET::AGA {
            uword n = min(count, 256)
            ; table: 1 long (count << 16 | start) + n*3 RGB longs + 1 terminator
            load_rgb32_table[0] = (n as long) << 16
            for i in 0 to n-1 {
                long rgb = rgb24[i]
                load_rgb32_table[1 + i*3]   = ((rgb >> 16) & $ff) << 24
                load_rgb32_table[1 + i*3+1] = ((rgb >> 8) & $ff) << 24
                load_rgb32_table[1 + i*3+2] = (rgb & $ff) << 24
            }
            load_rgb32_table[1 + n*3] = 0
            LoadRGB32(vp, &load_rgb32_table)
        } else {
            ; Static array + LoadRGB4 (no heap allocation, Kickstart 1.3 safe).
            uword no = min(count, 32) as uword
            for i in 0 to no-1 {
                long rgbo = rgb24[i]
                load_rgb4_table[i] = (((((rgbo >> 16) & $f0) >> 4) << 8) |
                                     ((((rgbo >> 8) & $f0) >> 4) << 4) |
                                     (((rgbo & $f0) >> 4))) as uword
            }
            LoadRGB4(vp, &load_rgb4_table, no as word)
        }
    }

    private long[770] load_rgb32_table
    private uword[32] load_rgb4_table


    sub load_iff_cmap(^^ViewPort vp, ^^ubyte cmap, uword count) {
        ; Load an IFF/ILBM CMAP chunk into a ViewPort's colormap. CMAP stores
        ; colors as packed RGB888 triples (3 bytes each: R, G, B) - a file
        ; format, not a hardware format - so the conversion differs per chipset:
        ; - AGA: 24-bit color registers, 8 bits per channel, lossless. Up to
        ;   256 entries (8 banks of 32 selected via BPLCON3).
        ; - OCS/ECS: 12-bit $0RGB registers, 4 bits per channel, so the low
        ;   nibble of each channel is dropped. 32 entries max.
        ; count is the number of colors in the chunk (chunk size / 3).
        ; This is the OS-friendly counterpart of custom.load_iff_cmap(), the
        ; hardware-banging version that pokes COLORxx directly for bare-metal
        ; use. Going through graphics.library here keeps the ViewPort's ColorMap
        ; and the hardware in agreement, which matters because Intuition's
        ; copper list reloads the registers from the ColorMap every frame.
        if count == 0
            return
        if custom.detect_chipset()==custom.CHIPSET::AGA {
            uword na = min(count, 256)
            for ia in 0 to na-1 {
                uword ba = ia*3
                long rgba = ((cmap[ba] as long) << 16) | ((cmap[ba+1] as long) << 8) | (cmap[ba+2] as long)
                set_palette_color(vp, ia, rgba)
            }
        } else {
            uword no = min(count, 32) as uword
            for io in 0 to no-1 {
                uword bo = (io as uword)*3
                long rgbo = ((cmap[bo] as long) << 16) | ((cmap[bo+1] as long) << 8) | (cmap[bo+2] as long)
                set_palette_color(vp, io as uword, rgbo)
            }
        }
    }

    sub set_palette_color(^^ViewPort vp, uword index, long rgb24) {
        ; Single canonical color into a ViewPort's colormap. Index above 31
        ; is ignored on ECS.
        if custom.detect_chipset()==custom.CHIPSET::AGA {
            SetRGB32(vp, index as long, ((rgb24 >> 16) & $ff) << 24,
                     ((rgb24 >> 8) & $ff) << 24, (rgb24 & $ff) << 24)
        } else {
            if index > 31
                return
            SetRGB4(vp, index as word, (((rgb24 >> 16) & $f0) >> 4) as ubyte,
                    (((rgb24 >> 8) & $f0) >> 4) as ubyte, ((rgb24 & $f0) >> 4) as ubyte)
        }
    }

    ; ===== RastPort flag macros from the C header graphics/gfxmacros.h =====
    ; BNDRYOFF/SetOPen are C macros in the NDK, they are never executed
    ; through the library base (no LVO), so they get handwritten subroutines here,
    ; named exactly like the C macros.

    const uword AREAOUTLINE = $0008     ; RastPort flag bit 3, used by areafiller

    sub BNDRYOFF(^^RastPort rp) {
        ; Stop outlining filled areas with the outline pen; clears the
        ; RastPort AREAOUTLINE flag. Same name as the C macro in gfxmacros.h.
        rp.Flags &= ~AREAOUTLINE
    }

    sub SetOPen(^^RastPort rp, ubyte pen) {
        ; Outline filled areas with pen; same name as the C macro in gfxmacros.h.
        rp.AOlPen = pen as byte
        rp.Flags |= AREAOUTLINE
    }

    sub SetDrPt(^^RastPort rp, uword pattern) {
        ; Start drawing dotted lines with the pattern (same name as the
        ; C macro). FRST_DOT makes Draw() plot the first dot of each line,
        ; Linpatcnt gets a full pattern period.
        rp.LinePtrn = pattern
        rp.Flags |= RPF_FRST_DOT
        rp.Linpatcnt = 15
    }

    sub SetAfPt(^^RastPort rp, pointer pattern, ubyte size) {
        ; Use a repeating pattern for area fills (same name as the C
        ; macro). pattern points to the fill template, size is the log2
        ; word count the template (0 = solid fill).
        rp.AreaPtrn = pattern
        rp.AreaPtSz = size as byte
    }

    sub SetWrMsk(^^RastPort rp, ubyte mask) {
        ; Pixel write mask: raster words only update where mask is set
        ; (same name as the C macro).
        rp.Mask = mask
    }

    sub SafeSetOutlinePen(^^RastPort rp, ubyte pen) {
        ; Kickstart-safe outline pen selection (same name as the C macro):
        ; the V39 SetOutlinePen() LVO on Kickstart 3.0+ (exec version 39+),
        ; otherwise the older SetOPen() field pokes.
        if sys.exec_version() >= 39
            void SetOutlinePen(rp, pen as long)
        else
            SetOPen(rp, pen)
    }

    sub SafeSetWriteMask(^^RastPort rp, ubyte mask) {
        ; Kickstart-safe pixel write mask (same name as the C macro):
        ; the V39 SetWriteMask() LVO on Kickstart 3.0+ (exec version 39+),
        ; otherwise the direct Mask field poke.
        if sys.exec_version() >= 39
            void SetWriteMask(rp, mask as long)
        else
            rp.Mask = mask
    }

    extsub @bank 3   -30 = BltBitMap(^^BitMap srcBitMap @A0, word xSrc @D0, word ySrc @D1, ^^BitMap destBitMap @A1, word xDest @D2, word yDest @D3, word xSize @D4, word ySize @D5, ubyte minterm @D6, ubyte mask @D7, pointer tempA @A2) -> long @D0
    extsub @bank 3   -36 = BltTemplate(long source @A0, word xSrc @D0, word srcMod @D1, ^^RastPort destRP @A1, word xDest @D2, word yDest @D3, word xSize @D4, word ySize @D5)
    extsub @bank 3   -42 = ClearEOL(^^RastPort rp @A1)
    extsub @bank 3   -48 = ClearScreen(^^RastPort rp @A1)
    extsub @bank 3   -54 = TextLength(^^RastPort rp @A1, str string @A0, uword count @D0) -> word @D0
    extsub @bank 3   -60 = Text(^^RastPort rp @A1, str string @A0, uword count @D0) -> long @D0
    extsub @bank 3   -66 = SetFont(^^RastPort rp @A1, ^^TextFont textFont @A0) -> long @D0
    extsub @bank 3   -72 = OpenFont(^^TextAttr textAttr @A0) -> ^^TextFont @D0
    extsub @bank 3   -78 = CloseFont(^^TextFont textFont @A1)
    extsub @bank 3   -84 = AskSoftStyle(^^RastPort rp @A1) -> long @D0
    extsub @bank 3   -90 = SetSoftStyle(^^RastPort rp @A1, long style @D0, long enable @D1) -> long @D0
    extsub @bank 3   -96 = AddBob(pointer bob @A0, ^^RastPort rp @A1)
    extsub @bank 3   -102 = AddVSprite(pointer vSprite @A0, ^^RastPort rp @A1)
    extsub @bank 3   -108 = DoCollision(^^RastPort rp @A1)
    extsub @bank 3   -114 = DrawGList(^^RastPort rp @A1, ^^ViewPort vp @A0)
    extsub @bank 3   -120 = InitGels(pointer head @A0, pointer tail @A1, pointer gelsInfo @A2)
    extsub @bank 3   -126 = InitMasks(pointer vSprite @A0)
    extsub @bank 3   -132 = RemIBob(pointer bob @A0, ^^RastPort rp @A1, ^^ViewPort vp @A2)
    extsub @bank 3   -138 = RemVSprite(pointer vSprite @A0)
    extsub @bank 3   -144 = SetCollision(long num @D0, pointer routine @A0, pointer gelsInfo @A1)
    extsub @bank 3   -150 = SortGList(^^RastPort rp @A1)
    extsub @bank 3   -156 = AddAnimOb(pointer anOb @A0, pointer anKey @A1, ^^RastPort rp @A2)
    extsub @bank 3   -162 = Animate(pointer anKey @A0, ^^RastPort rp @A1)
    extsub @bank 3   -168 = GetGBuffers(pointer anOb @A0, ^^RastPort rp @A1, bool flag @D0) -> bool @D0
    extsub @bank 3   -174 = InitGMasks(pointer anOb @A0)
    extsub @bank 3   -180 = DrawEllipse(^^RastPort rp @A1, word xCenter @D0, word yCenter @D1, word a @D2, word b @D3)
    extsub @bank 3   -186 = AreaEllipse(^^RastPort rp @A1, word xCenter @D0, word yCenter @D1, word a @D2, word b @D3) -> long @D0
    extsub @bank 3   -192 = LoadRGB4(^^ViewPort vp @A0, pointer colors @A1, word count @D0)
    extsub @bank 3   -198 = InitRastPort(^^RastPort rp @A1)
    extsub @bank 3   -204 = InitVPort(^^ViewPort vp @A0)
    extsub @bank 3   -210 = MrgCop(^^View view @A1) -> long @D0
    extsub @bank 3   -216 = MakeVPort(^^View view @A0, ^^ViewPort vp @A1) -> long @D0
    extsub @bank 3   -222 = LoadView(^^View view @A1)
    extsub @bank 3   -228 = WaitBlit()
    extsub @bank 3   -234 = SetRast(^^RastPort rp @A1, ubyte pen @D0)
    extsub @bank 3   -240 = Move(^^RastPort rp @A1, word x @D0, word y @D1)
    extsub @bank 3   -246 = Draw(^^RastPort rp @A1, word x @D0, word y @D1)
    extsub @bank 3   -252 = AreaMove(^^RastPort rp @A1, word x @D0, word y @D1) -> long @D0
    extsub @bank 3   -258 = AreaDraw(^^RastPort rp @A1, word x @D0, word y @D1) -> long @D0
    extsub @bank 3   -264 = AreaEnd(^^RastPort rp @A1) -> long @D0
    extsub @bank 3   -270 = WaitTOF()
    extsub @bank 3   -276 = QBlit(pointer blit @A1)
    extsub @bank 3   -282 = InitArea(^^AreaInfo areaInfo @A0, pointer vectorBuffer @A1, word maxVectors @D0)
    extsub @bank 3   -288 = SetRGB4(^^ViewPort vp @A0, word index @D0, ubyte red @D1, ubyte green @D2, ubyte blue @D3)
    extsub @bank 3   -294 = QBSBlit(pointer blit @A1)
    extsub @bank 3   -300 = BltClear(pointer memBlock @A1, long byteCount @D0, long flags @D1)
    extsub @bank 3   -306 = RectFill(^^RastPort rp @A1, word xMin @D0, word yMin @D1, word xMax @D2, word yMax @D3)
    extsub @bank 3   -312 = BltPattern(^^RastPort rp @A1, long mask @A0, word xMin @D0, word yMin @D1, word xMax @D2, word yMax @D3, uword maskBPR @D4)
    extsub @bank 3   -318 = ReadPixel(^^RastPort rp @A1, word x @D0, word y @D1) -> long @D0
    extsub @bank 3   -324 = WritePixel(^^RastPort rp @A1, word x @D0, word y @D1) -> long @D0
    extsub @bank 3   -330 = Flood(^^RastPort rp @A1, long mode @D2, word x @D0, word y @D1) -> bool @D0
    extsub @bank 3   -336 = PolyDraw(^^RastPort rp @A1, word count @D0, pointer polyTable @A0)
    extsub @bank 3   -342 = SetAPen(^^RastPort rp @A1, ubyte pen @D0)
    extsub @bank 3   -348 = SetBPen(^^RastPort rp @A1, ubyte pen @D0)
    extsub @bank 3   -354 = SetDrMd(^^RastPort rp @A1, ubyte drawMode @D0)
    extsub @bank 3   -360 = InitView(^^View view @A1)
    extsub @bank 3   -366 = CBump(pointer copList @A1)
    extsub @bank 3   -372 = CMove(pointer copList @A1, pointer destination @D0, word data @D1) -> long @D0
    extsub @bank 3   -378 = CWait(pointer copList @A1, word v @D0, word h @D1) -> long @D0
    extsub @bank 3   -384 = VBeamPos() -> long @D0
    extsub @bank 3   -390 = InitBitMap(^^BitMap bitMap @A0, byte depth @D0, word width @D1, word height @D2)
    extsub @bank 3   -396 = ScrollRaster(^^RastPort rp @A1, word dx @D0, word dy @D1, word xMin @D2, word yMin @D3, word xMax @D4, word yMax @D5)
    extsub @bank 3   -402 = WaitBOVP(^^ViewPort vp @A0)
    extsub @bank 3   -408 = GetSprite(pointer sprite @A0, word num @D0) -> word @D0
    extsub @bank 3   -414 = FreeSprite(word num @D0)
    extsub @bank 3   -420 = ChangeSprite(^^ViewPort vp @A0, pointer sprite @A1, pointer newData @A2)
    extsub @bank 3   -426 = MoveSprite(^^ViewPort vp @A0, pointer sprite @A1, word x @D0, word y @D1)
    extsub @bank 3   -432 = LockLayerRom(^^Layer layer @A5)
    extsub @bank 3   -438 = UnlockLayerRom(^^Layer layer @A5)
    extsub @bank 3   -444 = SyncSBitMap(^^Layer layer @A0)
    extsub @bank 3   -450 = CopySBitMap(^^Layer layer @A0)
    extsub @bank 3   -456 = OwnBlitter()
    extsub @bank 3   -462 = DisownBlitter()
    extsub @bank 3   -468 = InitTmpRas(^^TmpRas tmpRas @A0, pointer buffer @A1, long size @D0) -> ^^TmpRas @D0
    extsub @bank 3   -474 = AskFont(^^RastPort rp @A1, ^^TextAttr textAttr @A0)
    extsub @bank 3   -480 = AddFont(^^TextFont textFont @A1)
    extsub @bank 3   -486 = RemFont(^^TextFont textFont @A1)
    extsub @bank 3   -492 = AllocRaster(uword width @D0, uword height @D1) -> pointer @D0
    extsub @bank 3   -498 = FreeRaster(pointer p @A0, uword width @D0, uword height @D1)
    extsub @bank 3   -504 = AndRectRegion(pointer region @A0, pointer rectangle @A1)
    extsub @bank 3   -510 = OrRectRegion(pointer region @A0, pointer rectangle @A1) -> bool @D0
    extsub @bank 3   -516 = NewRegion() -> pointer @D0
    extsub @bank 3   -522 = ClearRectRegion(pointer region @A0, pointer rectangle @A1) -> bool @D0
    extsub @bank 3   -528 = ClearRegion(pointer region @A0)
    extsub @bank 3   -534 = DisposeRegion(pointer region @A0)
    extsub @bank 3   -540 = FreeVPortCopLists(^^ViewPort vp @A0)
    extsub @bank 3   -546 = FreeCopList(pointer copList @A0)
    extsub @bank 3   -552 = ClipBlit(^^RastPort srcRP @A0, word xSrc @D0, word ySrc @D1, ^^RastPort destRP @A1, word xDest @D2, word yDest @D3, word xSize @D4, word ySize @D5, ubyte minterm @D6)
    extsub @bank 3   -558 = XorRectRegion(pointer region @A0, pointer rectangle @A1) -> bool @D0
    extsub @bank 3   -564 = FreeCprList(pointer cprList @A0)
    extsub @bank 3   -570 = GetColorMap(long entries @D0) -> ^^ColorMap @D0
    extsub @bank 3   -576 = FreeColorMap(^^ColorMap colorMap @A0)
    extsub @bank 3   -582 = GetRGB4(^^ColorMap colorMap @A0, long entry @D0) -> long @D0
    extsub @bank 3   -588 = ScrollVPort(^^ViewPort vp @A0)
    extsub @bank 3   -594 = UCopperListInit(pointer uCopList @A0, word n @D0) -> pointer @D0
    extsub @bank 3   -600 = FreeGBuffers(pointer anOb @A0, ^^RastPort rp @A1, bool flag @D0)
    extsub @bank 3   -606 = BltBitMapRastPort(^^BitMap srcBitMap @A0, word xSrc @D0, word ySrc @D1, ^^RastPort destRP @A1, word xDest @D2, word yDest @D3, word xSize @D4, word ySize @D5, ubyte minterm @D6)
    extsub @bank 3   -612 = OrRegionRegion(pointer srcRegion @A0, pointer destRegion @A1) -> bool @D0
    extsub @bank 3   -618 = XorRegionRegion(pointer srcRegion @A0, pointer destRegion @A1) -> bool @D0
    extsub @bank 3   -624 = AndRegionRegion(pointer srcRegion @A0, pointer destRegion @A1) -> bool @D0
    extsub @bank 3   -630 = SetRGB4CM(^^ColorMap colorMap @A0, word index @D0, ubyte red @D1, ubyte green @D2, ubyte blue @D3)
    extsub @bank 3   -636 = BltMaskBitMapRastPort(^^BitMap srcBitMap @A0, word xSrc @D0, word ySrc @D1, ^^RastPort destRP @A1, word xDest @D2, word yDest @D3, word xSize @D4, word ySize @D5, ubyte minterm @D6, long bltMask @A2)
    extsub @bank 3   -654 = AttemptLockLayerRom(^^Layer layer @A5) -> bool @D0
    extsub @bank 3   -660 = GfxNew(long gfxNodeType @D0) -> pointer @D0
    extsub @bank 3   -666 = GfxFree(pointer gfxNodePtr @A0)
    extsub @bank 3   -672 = GfxAssociate(pointer associateNode @A0, pointer gfxNodePtr @A1)
    extsub @bank 3   -678 = BitMapScale(pointer bitScaleArgs @A0)
    extsub @bank 3   -684 = ScalerDiv(uword factor @D0, uword numerator @D1, uword denominator @D2) -> uword @D0
    extsub @bank 3   -690 = TextExtent(^^RastPort rp @A1, str string @A0, word count @D0, pointer textExtent @A2) -> word @D0
    extsub @bank 3   -696 = TextFit(^^RastPort rp @A1, str string @A0, uword strLen @D0, pointer textExtent @A2, pointer constrainingExtent @A3, word strDirection @D1, uword constrainingBitWidth @D2, uword constrainingBitHeight @D3) -> long @D0
    extsub @bank 3   -702 = GfxLookUp(pointer associateNode @A0) -> pointer @D0
    extsub @bank 3   -708 = VideoControl(^^ColorMap colorMap @A0, pointer tagarray @A1) -> bool @D0
    extsub @bank 3   -714 = OpenMonitor(str monitorName @A1, long displayID @D0) -> pointer @D0
    extsub @bank 3   -720 = CloseMonitor(pointer monitorSpec @A0) -> bool @D0
    extsub @bank 3   -726 = FindDisplayInfo(long displayID @D0) -> pointer @D0
    extsub @bank 3   -732 = NextDisplayInfo(long displayID @D0) -> long @D0
    extsub @bank 3   -756 = GetDisplayInfoData(pointer handle @A0, pointer buf @A1, long size @D0, long tagID @D1, long displayID @D2) -> long @D0
    extsub @bank 3   -762 = FontExtent(^^TextFont font @A0, pointer fontExtent @A1)
    extsub @bank 3   -768 = ReadPixelLine8(^^RastPort rp @A0, uword xstart @D0, uword ystart @D1, uword width @D2, pointer array @A2, ^^RastPort tempRP @A1) -> long @D0
    extsub @bank 3   -774 = WritePixelLine8(^^RastPort rp @A0, uword xstart @D0, uword ystart @D1, uword width @D2, pointer array @A2, ^^RastPort tempRP @A1) -> long @D0
    extsub @bank 3   -780 = ReadPixelArray8(^^RastPort rp @A0, uword xstart @D0, uword ystart @D1, uword xstop @D2, uword ystop @D3, pointer array @A2, ^^RastPort temprp @A1) -> long @D0
    extsub @bank 3   -786 = WritePixelArray8(^^RastPort rp @A0, uword xstart @D0, uword ystart @D1, uword xstop @D2, uword ystop @D3, pointer array @A2, ^^RastPort temprp @A1) -> long @D0
    extsub @bank 3   -792 = GetVPModeID(^^ViewPort vp @A0) -> long @D0
    extsub @bank 3   -798 = ModeNotAvailable(long modeID @D0) -> long @D0
    extsub @bank 3   -804 = WeighTAMatch(^^TextAttr reqTextAttr @A0, ^^TextAttr targetTextAttr @A1, pointer targetTags @A2) -> word @D0
    extsub @bank 3   -810 = EraseRect(^^RastPort rp @A1, word xMin @D0, word yMin @D1, word xMax @D2, word yMax @D3)
    extsub @bank 3   -816 = ExtendFont(^^TextFont font @A0, pointer fontTags @A1) -> long @D0
    extsub @bank 3   -822 = StripFont(^^TextFont font @A0)
    extsub @bank 3   -828 = CalcIVG(^^View v @A0, ^^ViewPort vp @A1) -> uword @D0
    extsub @bank 3   -834 = AttachPalExtra(^^ColorMap cm @A0, ^^ViewPort vp @A1) -> long @D0
    extsub @bank 3   -840 = ObtainBestPenA(^^ColorMap cm @A0, long r @D1, long g @D2, long b @D3, pointer tags @A1) -> long @D0
    extsub @bank 3   -852 = SetRGB32(^^ViewPort vp @A0, long n @D0, long r @D1, long g @D2, long b @D3)
    extsub @bank 3   -858 = GetAPen(^^RastPort rp @A0) -> long @D0
    extsub @bank 3   -864 = GetBPen(^^RastPort rp @A0) -> long @D0
    extsub @bank 3   -870 = GetDrMd(^^RastPort rp @A0) -> long @D0
    extsub @bank 3   -876 = GetOutlinePen(^^RastPort rp @A0) -> long @D0
    extsub @bank 3   -882 = LoadRGB32(^^ViewPort vp @A0, pointer table @A1)
    extsub @bank 3   -888 = SetChipRev(long want @D0) -> long @D0
    extsub @bank 3   -894 = SetABPenDrMd(^^RastPort rp @A1, long apen @D0, long bpen @D1, long drawmode @D2)
    extsub @bank 3   -900 = GetRGB32(^^ColorMap cm @A0, long firstcolor @D0, long ncolors @D1, pointer table @A1)
    extsub @bank 3   -918 = AllocBitMap(long sizex @D0, long sizey @D1, long depth @D2, long flags @D3, ^^BitMap friend_bitmap @A0) -> ^^BitMap @D0
    extsub @bank 3   -924 = FreeBitMap(^^BitMap bm @A0)
    extsub @bank 3   -930 = GetExtSpriteA(pointer ss @A2, pointer tags @A1) -> long @D0
    extsub @bank 3   -936 = CoerceMode(^^ViewPort vp @A0, long monitorid @D0, long flags @D1) -> long @D0
    extsub @bank 3   -942 = ChangeVPBitMap(^^ViewPort vp @A0, ^^BitMap bm @A1, pointer db @A2)
    extsub @bank 3   -948 = ReleasePen(^^ColorMap cm @A0, long n @D0)
    extsub @bank 3   -954 = ObtainPen(^^ColorMap cm @A0, long n @D0, long r @D1, long g @D2, long b @D3, long f @D4) -> long @D0
    extsub @bank 3   -960 = GetBitMapAttr(^^BitMap bm @A0, long attrnum @D1) -> long @D0
    extsub @bank 3   -966 = AllocDBufInfo(^^ViewPort vp @A0) -> pointer @D0
    extsub @bank 3   -972 = FreeDBufInfo(pointer dbi @A1)
    extsub @bank 3   -978 = SetOutlinePen(^^RastPort rp @A0, long pen @D0) -> long @D0
    extsub @bank 3   -984 = SetWriteMask(^^RastPort rp @A0, long msk @D0) -> long @D0
    extsub @bank 3   -990 = SetMaxPen(^^RastPort rp @A0, long maxpen @D0)
    extsub @bank 3   -996 = SetRGB32CM(^^ColorMap cm @A0, long n @D0, long r @D1, long g @D2, long b @D3)
    extsub @bank 3   -1002 = ScrollRasterBF(^^RastPort rp @A1, word dx @D0, word dy @D1, word xMin @D2, word yMin @D3, word xMax @D4, word yMax @D5)
    extsub @bank 3   -1008 = FindColor(^^ColorMap cm @A3, long r @D1, long g @D2, long b @D3, long maxcolor @D4) -> long @D0
    extsub @bank 3   -1020 = AllocSpriteDataA(^^BitMap bm @A2, pointer tags @A1) -> pointer @D0
    extsub @bank 3   -1026 = ChangeExtSpriteA(^^ViewPort vp @A0, pointer oldsprite @A1, pointer newsprite @A2, pointer tags @A3) -> long @D0
    extsub @bank 3   -1032 = FreeSpriteData(pointer sp @A2)
    extsub @bank 3   -1038 = SetRPAttrsA(^^RastPort rp @A0, pointer tags @A1)
    extsub @bank 3   -1044 = GetRPAttrsA(^^RastPort rp @A0, pointer tags @A1)
    extsub @bank 3   -1050 = BestModeIDA(pointer tags @A0) -> long @D0
    extsub @bank 3   -1056 = WriteChunkyPixels(^^RastPort rp @A0, uword xstart @D0, uword ystart @D1, uword xstop @D2, uword ystop @D3, pointer array @A2, long bytesperrow @D4)

    ; ---- struct definitions ----

    struct AreaInfo {  ; total size: 24
        pointer VctrTbl  ; 0
        pointer VctrPtr  ; 4
        pointer FlagTbl  ; 8
        pointer FlagPtr  ; 12
        word Count  ; 16
        word MaxCount  ; 18
        word FirstX  ; 20
        word FirstY  ; 22
    }

    struct BitMap {  ; total size: 40
        uword BytesPerRow  ; 0
        uword Rows  ; 2
        ubyte Flags  ; 4
        ubyte Depth  ; 5
        uword Pad  ; 6
        pointer[8] Planes  ; 8
    }

    struct ClipRect {  ; total size: 36
        ^^ClipRect Next  ; 0
        ^^ClipRect Reservedlink  ; 4
        long Obscured  ; 8
        ^^BitMap BitMap  ; 12
        ubyte[8] emb_Bounds  ; 16
        ^^ClipRect Vlink  ; 24
        pointer Home  ; 28
        pointer Reserved  ; 32
    }

    struct ColorMap {  ; total size: 52
        ubyte Flags  ; 0
        ubyte Type  ; 1
        uword Count  ; 2
        pointer ColorTable  ; 4
        pointer Vpe  ; 8
        pointer LowColorBits  ; 12
        ubyte TransparencyPlane  ; 16
        ubyte SpriteResolution  ; 17
        ubyte SpriteResDefault  ; 18
        ubyte AuxFlags  ; 19
        ^^ViewPort Vp  ; 20
        pointer NormalDisplayInfo  ; 24
        pointer CoerceDisplayInfo  ; 28
        ^^utility.TagItem Batch_items  ; 32
        long VPModeID  ; 36
        pointer PalExtra  ; 40
        uword Even  ; 44
        uword Odd  ; 46
        uword Bp_0_base  ; 48
        uword Bp_1_base  ; 50
    }

    struct Layer {  ; total size: 160
        ^^Layer Front  ; 0
        ^^Layer Back  ; 4
        ^^ClipRect ClipRect  ; 8
        ^^RastPort Rp  ; 12
        ubyte[8] emb_Bounds  ; 16
        ^^Layer Nlink  ; 24
        uword Priority  ; 28
        uword Flags  ; 30
        ^^BitMap SuperBitMap  ; 32
        ^^ClipRect SuperClipRect  ; 36
        pointer Window  ; 40
        word X  ; 44
        word Y  ; 46
        ^^ClipRect OnScreen  ; 48
        ^^ClipRect OffScreen  ; 52
        ^^ClipRect Backup  ; 56
        ^^ClipRect SuperSaveClipRects  ; 60
        ^^ClipRect Undamaged  ; 64
        pointer LayerInfo  ; 68
        ubyte[46] emb_Lock  ; 72
        ^^utility.Hook BackFill  ; 118
        long Reserved1  ; 122
        pointer ClipRegion  ; 126
        ^^ClipRect Clipped  ; 130
        word Width  ; 134
        word Height  ; 136
        ubyte[18] Reserved2  ; 138
        pointer DamageList  ; 156
    }

    struct RasInfo {  ; total size: 12
        ^^RasInfo Next  ; 0
        ^^BitMap BitMap  ; 4
        word RxOffset  ; 8
        word RyOffset  ; 10
    }

    struct RastPort {  ; total size: 100
        ^^Layer Layer  ; 0
        ^^BitMap BitMap  ; 4
        pointer AreaPtrn  ; 8
        ^^TmpRas TmpRas  ; 12
        ^^AreaInfo AreaInfo  ; 16
        pointer GelsInfo  ; 20
        ubyte Mask  ; 24
        byte FgPen  ; 25
        byte BgPen  ; 26
        byte AOlPen  ; 27
        byte DrawMode  ; 28
        byte AreaPtSz  ; 29
        byte Linpatcnt  ; 30
        byte Dummy  ; 31
        uword Flags  ; 32
        uword LinePtrn  ; 34
        word X  ; 36
        word Y  ; 38
        ubyte[8] Minterms  ; 40
        word PenWidth  ; 48
        word PenHeight  ; 50
        ^^TextFont Font  ; 52
        ubyte AlgoStyle  ; 56
        ubyte TxFlags  ; 57
        uword TxHeight  ; 58
        uword TxWidth  ; 60
        uword TxBaseline  ; 62
        word TxSpacing  ; 64
        pointer User  ; 66
        long[2] Longreserved  ; 70
        uword[7] Wordreserved  ; 78
        ubyte[8] Reserved  ; 92
    }

    struct TextAttr {  ; total size: 8
        str Name  ; 0
        uword YSize  ; 4
        ubyte Style  ; 6
        ubyte Flags  ; 7
    }

    struct TextExtent {  ; total size: 12
        uword Width  ; 0
        uword Height  ; 2
        ubyte[8] emb_Extent  ; 4
    }

    struct TextFont {  ; total size: 52
        ^^exec.Node Succ  ; 0
        ^^exec.Node Pred  ; 4
        ubyte Type  ; 8
        byte Pri  ; 9
        str Name  ; 10
        ^^exec.MsgPort ReplyPort  ; 14
        uword Length  ; 18
        uword YSize  ; 20
        ubyte Style  ; 22
        ubyte Flags  ; 23
        uword XSize  ; 24
        uword Baseline  ; 26
        uword BoldSmear  ; 28
        uword Accessors  ; 30
        ubyte LoChar  ; 32
        ubyte HiChar  ; 33
        pointer CharData  ; 34
        uword Modulo  ; 38
        pointer CharLoc  ; 40
        pointer CharSpace  ; 44
        pointer CharKern  ; 48
    }

    struct TmpRas {  ; total size: 8
        pointer RasPtr  ; 0
        long Size  ; 4
    }

    struct View {  ; total size: 18
        ^^ViewPort ViewPort  ; 0
        pointer LOFCprList  ; 4
        pointer SHFCprList  ; 8
        word DyOffset  ; 12
        word DxOffset  ; 14
        uword Modes  ; 16
    }

    struct ViewPort {  ; total size: 40
        ^^ViewPort Next  ; 0
        ^^ColorMap ColorMap  ; 4
        pointer DspIns  ; 8
        pointer SprIns  ; 12
        pointer ClrIns  ; 16
        pointer UCopIns  ; 20
        word DWidth  ; 24
        word DHeight  ; 26
        word DxOffset  ; 28
        word DyOffset  ; 30
        uword Modes  ; 32
        ubyte SpritePriorities  ; 34
        ubyte ExtendedModes  ; 35
        ^^RasInfo RasInfo  ; 36
    }

    ; ---- constants ----
    const ubyte NEWLOCKS = $0001
    const ubyte CR_NEEDS_NO_CONCEALED_RASTERS = $0001
    const ubyte CR_NEEDS_NO_LAYERBLIT_DAMAGE = $0002
    const ubyte ISLESSX = $0001
    const ubyte ISLESSY = $0002
    const ubyte ISGRTRX = $0004
    const ubyte ISGRTRY = $0008
    const ubyte PRESERVE_COLORS = $0001
    const ubyte AVOID_FLICKER = $0002
    const ubyte IGNORE_MCOMPAT = $0004
    const ubyte COPPER_MOVE = $0000
    const ubyte COPPER_WAIT = $0001
    const ubyte CPRNXTBUF = $0002
    const uword CPR_NT_LOF = $8000
    const uword CPR_NT_SHT = $4000
    const uword CPR_NT_SYS = $2000
    const ubyte EXACT_LINE = $0001
    const ubyte HALF_LINE = $0002
    const uword MODE_640 = $8000
    const ubyte PLNCNTMSK = $7
    const ubyte PLNCNTSHFT = $000c
    const ubyte PF2PRI = $40
    const uword COLORON = $0200
    const uword DBLPF = $400
    const uword HOLDNMODIFY = $800
    const ubyte INTERLACE = $0004
    const ubyte PFA_FINE_SCROLL = $F
    const ubyte PFB_FINE_SCROLL_SHIFT = $0004
    const ubyte PF_FINE_SCROLL_MASK = $F
    const ubyte DIW_HORIZ_POS = $7F
    const uword DIW_VRTCL_POS = $1FF
    const ubyte DIW_VRTCL_POS_SHIFT = $0007
    const ubyte DFTCH_MASK = $FF
    const uword VPOSRLOF = $8000
    const long DTAG_DISP = $80000000
    const long DTAG_DIMS = $80001000
    const long DTAG_MNTR = $80002000
    const long DTAG_NAME = $80003000
    const long DTAG_VEC = $80004000
    const uword DI_AVAIL_NOCHIPS = $0001
    const uword DI_AVAIL_NOMONITOR = $0002
    const uword DI_AVAIL_NOTWITHGENLOCK = $0004
    const long DIPF_IS_LACE = $00000001
    const long DIPF_IS_DUALPF = $00000002
    const long DIPF_IS_PF2PRI = $00000004
    const long DIPF_IS_HAM = $00000008
    const long DIPF_IS_ECS = $00000010
    const long DIPF_IS_AA = $00010000
    const long DIPF_IS_PAL = $00000020
    const long DIPF_IS_SPRITES = $00000040
    const long DIPF_IS_GENLOCK = $00000080
    const long DIPF_IS_WB = $00000100
    const long DIPF_IS_DRAGGABLE = $00000200
    const long DIPF_IS_PANELLED = $00000400
    const long DIPF_IS_BEAMSYNC = $00000800
    const long DIPF_IS_EXTRAHALFBRITE = $00001000
    const long DIPF_IS_SPRITES_ATT = $00002000
    const long DIPF_IS_SPRITES_CHNG_RES = $00004000
    const long DIPF_IS_SPRITES_BORDER = $00008000
    const long DIPF_IS_SCANDBL = $00020000
    const long DIPF_IS_SPRITES_CHNG_BASE = $00040000
    const long DIPF_IS_SPRITES_CHNG_PRI = $00080000
    const long DIPF_IS_DBUFFER = $00100000
    const long DIPF_IS_PROGBEAM = $00200000
    const long DIPF_IS_FOREIGN = $80000000
    const ubyte MCOMPAT_MIXED = $0000
    const ubyte MCOMPAT_SELF = $0001
    const long MCOMPAT_NOBODY = -1
    const ubyte DISPLAYNAMELEN = $0020
    const uword SUSERFLAGS = $00FF
    const ubyte VSB_VSPRITE = 0
    const ubyte VSF_VSPRITE = $0001
    const ubyte VSB_SAVEBACK = 1
    const ubyte VSF_SAVEBACK = $0002
    const ubyte VSB_OVERLAY = 2
    const ubyte VSF_OVERLAY = $0004
    const ubyte VSB_MUSTDRAW = 3
    const ubyte VSF_MUSTDRAW = $0008
    const ubyte VSB_BACKSAVED = 8
    const uword VSF_BACKSAVED = $0100
    const ubyte VSB_BOBUPDATE = 9
    const uword VSF_BOBUPDATE = $0200
    const ubyte VSB_GELGONE = 10
    const uword VSF_GELGONE = $0400
    const ubyte VSB_VSOVERFLOW = 11
    const uword VSF_VSOVERFLOW = $0800
    const uword BUSERFLAGS = $00FF
    const ubyte BB_SAVEBOB = 0
    const ubyte BF_SAVEBOB = $0001
    const ubyte BB_BOBISCOMP = 1
    const ubyte BF_BOBISCOMP = $0002
    const ubyte BB_BWAITING = 8
    const uword BF_BWAITING = $0100
    const ubyte BB_BDRAWN = 9
    const uword BF_BDRAWN = $0200
    const ubyte BB_BOBSAWAY = 10
    const uword BF_BOBSAWAY = $0400
    const ubyte BB_BOBNIX = 11
    const uword BF_BOBNIX = $0800
    const ubyte BB_SAVEPRESERVE = 12
    const uword BF_SAVEPRESERVE = $1000
    const ubyte BB_OUTSTEP = 13
    const uword BF_OUTSTEP = $2000
    const ubyte ANFRACSIZE = $0006
    const uword ANIMHALF = $0020
    const uword RINGTRIGGER = $0001
    const uword BITSET = $8000
    const ubyte BITCLR = $0000
    const ubyte AGNUS = $0001
    const ubyte DENISE = $0001
    const ubyte BMB_CLEAR = 0
    const ubyte BMF_CLEAR = $0001
    const ubyte BMB_DISPLAYABLE = 1
    const ubyte BMF_DISPLAYABLE = $0002
    const ubyte BMB_INTERLEAVED = 2
    const ubyte BMF_INTERLEAVED = $0004
    const ubyte BMB_STANDARD = 3
    const ubyte BMF_STANDARD = $0008
    const ubyte BMB_MINPLANES = 4
    const ubyte BMF_MINPLANES = $0010
    const ubyte BMB_HIJACKED = 7
    const ubyte BMF_HIJACKED = $0080
    const ubyte BMB_RTGTAGS = 8
    const uword BMF_RTGTAGS = $0100
    const ubyte BMB_RTGCHECK = 9
    const uword BMF_RTGCHECK = $0200
    const ubyte BMB_FRIENDISTAG = 10
    const uword BMF_FRIENDISTAG = $0400
    const ubyte BMB_INVALID = 11
    const uword BMF_INVALID = $0800
    const ubyte BMA_HEIGHT = $0000
    const ubyte BMA_DEPTH = $0004
    const ubyte BMA_WIDTH = $0008
    const ubyte BMA_FLAGS = $000c
    const long BMATags_Friend = $80000000
    const long BMATags_Depth = $80000001
    const long BMATags_PixelFormat = $80000002
    const long BMATags_Clear = $80000003
    const long BMATags_Displayable = $80000004
    const long BMATags_Private1 = $80000005
    const long BMATags_NoMemory = $80000006
    const long BMATags_NoSprite = $80000007
    const long BMATags_Private2 = $80000008
    const long BMATags_Private3 = $80000009
    const long BMATags_ModeWidth = $8000000a
    const long BMATags_ModeHeight = $8000000b
    const long BMATags_RenderFunc = $8000000c
    const long BMATags_SaveFunc = $8000000d
    const long BMATags_UserData = $8000000e
    const long BMATags_Alignment = $8000000f
    const long BMATags_ConstantBytesPerRow = $80000010
    const long BMATags_UserPrivate = $80000011
    const long BMATags_Private4 = $80000012
    const long BMATags_Private5 = $80000013
    const long BMATags_Private6 = $80000014
    const long BMATags_Private7 = $80000015
    const long BMATags_DisplayID = $80000032
    const long BMATags_BitmapInvisible = $80000037
    const long BMATags_BitmapColors = $80000029
    const long BMATags_BitmapColors32 = $80000043
    const ubyte OWNBLITTERn = $0000
    const ubyte QBOWNERn = $0001
    const ubyte BLITMSG_FAULTn = $0002
    const ubyte BLITMSG_FAULT = $0001
    const ubyte QBOWNER = $0001
    const ubyte GBFLAGSB_TIMER = 6
    const ubyte GBFLAGSF_TIMER = $0040
    const ubyte GBFLAGSB_LASTBLIT = 7
    const ubyte GBFLAGSF_LASTBLIT = $0080
    const ubyte GFXB_BIG_BLITS = 0
    const ubyte GFXF_BIG_BLITS = $0001
    const ubyte GFXB_HR_AGNUS = 0
    const ubyte GFXF_HR_AGNUS = $0001
    const ubyte GFXB_HR_DENISE = 1
    const ubyte GFXF_HR_DENISE = $0002
    const ubyte GFXB_AA_ALICE = 2
    const ubyte GFXF_AA_ALICE = $0004
    const ubyte GFXB_AA_LISA = 3
    const ubyte GFXF_AA_LISA = $0008
    const ubyte GFXB_AA_MLISA = 4
    const ubyte GFXF_AA_MLISA = $0010
    const long SETCHIPREV_BEST = $ffffffff
    const ubyte BUS_16 = $0000
    const ubyte NML_CAS = $0000
    const ubyte BUS_32 = $0001
    const ubyte DBL_CAS = $0002
    const ubyte NTSCn = $0000
    const ubyte NTSC = $0001
    const ubyte GENLOCn = $0001
    const ubyte GENLOC = $0001
    const ubyte PALn = $0002
    const ubyte PAL = $0001
    const ubyte TODA_SAFEn = $0003
    const ubyte TODA_SAFE = $0001
    const ubyte REALLY_PALn = $0004
    const ubyte REALLY_PAL = $0001
    const ubyte LPEN_SWAP_FRAMESn = $0005
    const ubyte LPEN_SWAP_FRAMES = $0001
    const ubyte GRAPHICS_GFXNODES_I = $0001
    const ubyte SS_GRAPHICS = $02
    const ubyte VIEW_EXTRA_TYPE = $0001
    const ubyte VIEWPORT_EXTRA_TYPE = $0002
    const ubyte SPECIAL_MONITOR_TYPE = $0003
    const ubyte MONITOR_SPEC_TYPE = $0004
    const ubyte LAYERSIMPLE = $0001
    const ubyte LAYERSMART = $0002
    const ubyte LAYERSUPER = $0004
    const ubyte LAYERUPDATING = $10
    const ubyte LAYERBACKDROP = $40
    const ubyte LAYERREFRESH = $80
    const uword LAYERIREFRESH = $200
    const uword LAYERIREFRESH2 = $400
    const uword LAYER_CLIPRECTS_LOST = $100
    const uword LAYERSAVEBACK = $800
    const uword LAYERHIDDEN = $1000
    const ubyte NEWLAYERINFO_CALLED = $0001
    const ubyte LAYERS_NOBACKFILL = $0001
    const ubyte LAYERS_BACKFILL = $0000
    const ubyte LAYER_BACKMOST = $0000
    const ubyte LAYER_FRONTMOST = $0001
    const long MONITOR_ID_MASK = $FFFF1000
    const long DEFAULT_MONITOR_ID = $00000000
    const long NTSC_MONITOR_ID = $00011000
    const long PAL_MONITOR_ID = $00021000
    const long LORES_KEY = $00000000
    const long HIRES_KEY = $00008000
    const long SUPER_KEY = $00008020
    const long HAM_KEY = $00000800
    const long LORESLACE_KEY = $00000004
    const long HIRESLACE_KEY = $00008004
    const long SUPERLACE_KEY = $00008024
    const long HAMLACE_KEY = $00000804
    const long LORESDPF_KEY = $00000400
    const long HIRESDPF_KEY = $00008400
    const long SUPERDPF_KEY = $00008420
    const long LORESLACEDPF_KEY = $00000404
    const long HIRESLACEDPF_KEY = $00008404
    const long SUPERLACEDPF_KEY = $00008424
    const long LORESDPF2_KEY = $00000440
    const long HIRESDPF2_KEY = $00008440
    const long SUPERDPF2_KEY = $00008460
    const long LORESLACEDPF2_KEY = $00000444
    const long HIRESLACEDPF2_KEY = $00008444
    const long SUPERLACEDPF2_KEY = $00008464
    const long EXTRAHALFBRITE_KEY = $00000080
    const long EXTRAHALFBRITELACE_KEY = $00000084
    const long HIRESHAM_KEY = $00008800
    const long SUPERHAM_KEY = $00008820
    const long HIRESEHB_KEY = $00008080
    const long SUPEREHB_KEY = $000080a0
    const long HIRESHAMLACE_KEY = $00008804
    const long SUPERHAMLACE_KEY = $00008824
    const long HIRESEHBLACE_KEY = $00008084
    const long SUPEREHBLACE_KEY = $000080a4
    const long LORESSDBL_KEY = $00000008
    const long LORESHAMSDBL_KEY = $00000808
    const long LORESEHBSDBL_KEY = $00000088
    const long HIRESHAMSDBL_KEY = $00008808
    const long VGA_MONITOR_ID = $00031000
    const long VGAEXTRALORES_KEY = $00031004
    const long VGALORES_KEY = $00039004
    const long VGAPRODUCT_KEY = $00039024
    const long VGAHAM_KEY = $00031804
    const long VGAEXTRALORESLACE_KEY = $00031005
    const long VGALORESLACE_KEY = $00039005
    const long VGAPRODUCTLACE_KEY = $00039025
    const long VGAHAMLACE_KEY = $00031805
    const long VGAEXTRALORESDPF_KEY = $00031404
    const long VGALORESDPF_KEY = $00039404
    const long VGAPRODUCTDPF_KEY = $00039424
    const long VGAEXTRALORESLACEDPF_KEY = $00031405
    const long VGALORESLACEDPF_KEY = $00039405
    const long VGAPRODUCTLACEDPF_KEY = $00039425
    const long VGAEXTRALORESDPF2_KEY = $00031444
    const long VGALORESDPF2_KEY = $00039444
    const long VGAPRODUCTDPF2_KEY = $00039464
    const long VGAEXTRALORESLACEDPF2_KEY = $00031445
    const long VGALORESLACEDPF2_KEY = $00039445
    const long VGAPRODUCTLACEDPF2_KEY = $00039465
    const long VGAEXTRAHALFBRITE_KEY = $00031084
    const long VGAEXTRAHALFBRITELACE_KEY = $00031085
    const long VGAPRODUCTHAM_KEY = $00039824
    const long VGALORESHAM_KEY = $00039804
    const long VGAPRODUCTHAMLACE_KEY = $00039825
    const long VGALORESHAMLACE_KEY = $00039805
    const long VGALORESEHB_KEY = $00039084
    const long VGALORESEHBLACE_KEY = $00039085
    const long VGAEHB_KEY = $000390a4
    const long VGAEHBLACE_KEY = $000390a5
    const long A2024_MONITOR_ID = $00041000
    const long A2024TENHERTZ_KEY = $00041000
    const long A2024FIFTEENHERTZ_KEY = $00049000
    const long PROTO_MONITOR_ID = $00051000
    const long EURO72_MONITOR_ID = $00061000
    const long EURO72EXTRALORES_KEY = $00061004
    const long EURO72LORES_KEY = $00069004
    const long EURO72PRODUCT_KEY = $00069024
    const long EURO72HAM_KEY = $00061804
    const long EURO72EXTRALORESLACE_KEY = $00061005
    const long EURO72LORESLACE_KEY = $00069005
    const long EURO72PRODUCTLACE_KEY = $00069025
    const long EURO72HAMLACE_KEY = $00061805
    const long EURO72EXTRALORESDPF_KEY = $00061404
    const long EURO72LORESDPF_KEY = $00069404
    const long EURO72PRODUCTDPF_KEY = $00069424
    const long EURO72EXTRALORESLACEDPF_KEY = $00061405
    const long EURO72LORESLACEDPF_KEY = $00069405
    const long EURO72PRODUCTLACEDPF_KEY = $00069425
    const long EURO72EXTRALORESDPF2_KEY = $00061444
    const long EURO72LORESDPF2_KEY = $00069444
    const long EURO72PRODUCTDPF2_KEY = $00069464
    const long EURO72EXTRALORESLACEDPF2_KEY = $00061445
    const long EURO72LORESLACEDPF2_KEY = $00069445
    const long EURO72PRODUCTLACEDPF2_KEY = $00069465
    const long EURO72EXTRAHALFBRITE_KEY = $00061084
    const long EURO72EXTRAHALFBRITELACE_KEY = $00061085
    const long EURO72PRODUCTHAM_KEY = $00069824
    const long EURO72PRODUCTHAMLACE_KEY = $00069825
    const long EURO72LORESHAM_KEY = $00069804
    const long EURO72LORESHAMLACE_KEY = $00069805
    const long EURO72LORESEHB_KEY = $00069084
    const long EURO72LORESEHBLACE_KEY = $00069085
    const long EURO72EHB_KEY = $000690a4
    const long EURO72EHBLACE_KEY = $000690a5
    const long EURO72EXTRALORESDBL_KEY = $00061000
    const long EURO72LORESDBL_KEY = $00069000
    const long EURO72PRODUCTDBL_KEY = $00069020
    const long EURO72EXTRALORESHAMDBL_KEY = $00061800
    const long EURO72LORESHAMDBL_KEY = $00069800
    const long EURO72PRODUCTHAMDBL_KEY = $00069820
    const long EURO72EXTRALORESEHBDBL_KEY = $00061080
    const long EURO72LORESEHBDBL_KEY = $00069080
    const long EURO72PRODUCTEHBDBL_KEY = $000690a0
    const long EURO36_MONITOR_ID = $00071000
    const long SUPER72_MONITOR_ID = $00081000
    const long SUPER72LORESDBL_KEY = $00081008
    const long SUPER72HIRESDBL_KEY = $00089008
    const long SUPER72SUPERDBL_KEY = $00089028
    const long SUPER72LORESHAMDBL_KEY = $00081808
    const long SUPER72HIRESHAMDBL_KEY = $00089808
    const long SUPER72SUPERHAMDBL_KEY = $00089828
    const long SUPER72LORESEHBDBL_KEY = $00081088
    const long SUPER72HIRESEHBDBL_KEY = $00089088
    const long SUPER72SUPEREHBDBL_KEY = $000890a8
    const long DBLNTSC_MONITOR_ID = $00091000
    const long DBLNTSCLORES_KEY = $00091000
    const long DBLNTSCLORESFF_KEY = $00091004
    const long DBLNTSCLORESHAM_KEY = $00091800
    const long DBLNTSCLORESHAMFF_KEY = $00091804
    const long DBLNTSCLORESEHB_KEY = $00091080
    const long DBLNTSCLORESEHBFF_KEY = $00091084
    const long DBLNTSCLORESLACE_KEY = $00091005
    const long DBLNTSCLORESHAMLACE_KEY = $00091805
    const long DBLNTSCLORESEHBLACE_KEY = $00091085
    const long DBLNTSCLORESDPF_KEY = $00091400
    const long DBLNTSCLORESDPFFF_KEY = $00091404
    const long DBLNTSCLORESDPFLACE_KEY = $00091405
    const long DBLNTSCLORESDPF2_KEY = $00091440
    const long DBLNTSCLORESDPF2FF_KEY = $00091444
    const long DBLNTSCLORESDPF2LACE_KEY = $00091445
    const long DBLNTSCHIRES_KEY = $00099000
    const long DBLNTSCHIRESFF_KEY = $00099004
    const long DBLNTSCHIRESHAM_KEY = $00099800
    const long DBLNTSCHIRESHAMFF_KEY = $00099804
    const long DBLNTSCHIRESLACE_KEY = $00099005
    const long DBLNTSCHIRESHAMLACE_KEY = $00099805
    const long DBLNTSCHIRESEHB_KEY = $00099080
    const long DBLNTSCHIRESEHBFF_KEY = $00099084
    const long DBLNTSCHIRESEHBLACE_KEY = $00099085
    const long DBLNTSCHIRESDPF_KEY = $00099400
    const long DBLNTSCHIRESDPFFF_KEY = $00099404
    const long DBLNTSCHIRESDPFLACE_KEY = $00099405
    const long DBLNTSCHIRESDPF2_KEY = $00099440
    const long DBLNTSCHIRESDPF2FF_KEY = $00099444
    const long DBLNTSCHIRESDPF2LACE_KEY = $00099445
    const long DBLNTSCEXTRALORES_KEY = $00091200
    const long DBLNTSCEXTRALORESHAM_KEY = $00091a00
    const long DBLNTSCEXTRALORESEHB_KEY = $00091280
    const long DBLNTSCEXTRALORESDPF_KEY = $00091600
    const long DBLNTSCEXTRALORESDPF2_KEY = $00091640
    const long DBLNTSCEXTRALORESFF_KEY = $00091204
    const long DBLNTSCEXTRALORESHAMFF_KEY = $00091a04
    const long DBLNTSCEXTRALORESEHBFF_KEY = $00091284
    const long DBLNTSCEXTRALORESDPFFF_KEY = $00091604
    const long DBLNTSCEXTRALORESDPF2FF_KEY = $00091644
    const long DBLNTSCEXTRALORESLACE_KEY = $00091205
    const long DBLNTSCEXTRALORESHAMLACE_KEY = $00091a05
    const long DBLNTSCEXTRALORESEHBLACE_KEY = $00091285
    const long DBLNTSCEXTRALORESDPFLACE_KEY = $00091605
    const long DBLNTSCEXTRALORESDPF2LACE_KEY = $00091645
    const long DBLPAL_MONITOR_ID = $000a1000
    const long DBLPALLORES_KEY = $000a1000
    const long DBLPALLORESFF_KEY = $000a1004
    const long DBLPALLORESHAM_KEY = $000a1800
    const long DBLPALLORESHAMFF_KEY = $000a1804
    const long DBLPALLORESEHB_KEY = $000a1080
    const long DBLPALLORESEHBFF_KEY = $000a1084
    const long DBLPALLORESLACE_KEY = $000a1005
    const long DBLPALLORESHAMLACE_KEY = $000a1805
    const long DBLPALLORESEHBLACE_KEY = $000a1085
    const long DBLPALLORESDPF_KEY = $000a1400
    const long DBLPALLORESDPFLACE_KEY = $000a1404
    const long DBLPALLORESDPF2_KEY = $000a1440
    const long DBLPALLORESDPF2LACE_KEY = $000a1444
    const long DBLPALHIRES_KEY = $000a9000
    const long DBLPALHIRESFF_KEY = $000a9004
    const long DBLPALHIRESHAM_KEY = $000a9800
    const long DBLPALHIRESHAMFF_KEY = $000a9804
    const long DBLPALHIRESLACE_KEY = $000a9005
    const long DBLPALHIRESHAMLACE_KEY = $000a9805
    const long DBLPALHIRESEHB_KEY = $000a9080
    const long DBLPALHIRESEHBFF_KEY = $000a9084
    const long DBLPALHIRESEHBLACE_KEY = $000a9085
    const long DBLPALHIRESDPF_KEY = $000a9400
    const long DBLPALHIRESDPFLACE_KEY = $000a9404
    const long DBLPALHIRESDPF2_KEY = $000a9440
    const long DBLPALHIRESDPF2LACE_KEY = $000a9444
    const long DBLPALEXTRALORES_KEY = $000a1200
    const long DBLPALEXTRALORESHAM_KEY = $000a1a00
    const long DBLPALEXTRALORESEHB_KEY = $000a1280
    const long DBLPALEXTRALORESDPF_KEY = $000a1600
    const long DBLPALEXTRALORESDPF2_KEY = $000a1640
    const long DBLPALEXTRALORESFF_KEY = $000a1204
    const long DBLPALEXTRALORESHAMFF_KEY = $000a1a04
    const long DBLPALEXTRALORESEHBFF_KEY = $000a1284
    const long DBLPALEXTRALORESDPFFF_KEY = $000a1604
    const long DBLPALEXTRALORESDPF2FF_KEY = $000a1644
    const long DBLPALEXTRALORESLACE_KEY = $000a1205
    const long DBLPALEXTRALORESHAMLACE_KEY = $000a1a05
    const long DBLPALEXTRALORESEHBLACE_KEY = $000a1285
    const long DBLPALEXTRALORESDPFLACE_KEY = $000a1605
    const long DBLPALEXTRALORESDPF2LACE_KEY = $000a1645
    const long BIDTAG_DIPFMustHave = $80000001
    const long BIDTAG_DIPFMustNotHave = $80000002
    const long BIDTAG_ViewPort = $80000003
    const long BIDTAG_NominalWidth = $80000004
    const long BIDTAG_NominalHeight = $80000005
    const long BIDTAG_DesiredWidth = $80000006
    const long BIDTAG_DesiredHeight = $80000007
    const long BIDTAG_Depth = $80000008
    const long BIDTAG_MonitorID = $80000009
    const long BIDTAG_SourceID = $8000000a
    const long BIDTAG_RedBits = $8000000b
    const long BIDTAG_BlueBits = $8000000c
    const long BIDTAG_GreenBits = $8000000d
    const long BIDTAG_GfxPrivate = $8000000e
    const ubyte MSB_REQUEST_NTSC = 0
    const ubyte MSF_REQUEST_NTSC = $0001
    const ubyte MSB_REQUEST_PAL = 1
    const ubyte MSF_REQUEST_PAL = $0002
    const ubyte MSB_REQUEST_SPECIAL = 2
    const ubyte MSF_REQUEST_SPECIAL = $0004
    const ubyte MSB_REQUEST_A2024 = 3
    const ubyte MSF_REQUEST_A2024 = $0008
    const ubyte MSB_DOUBLE_SPRITES = 4
    const ubyte MSF_DOUBLE_SPRITES = $0010
    const ubyte STANDARD_VIEW_X = $81
    const ubyte STANDARD_VIEW_Y = $2C
    const ubyte RPB_FRST_DOT = 0
    const ubyte RPF_FRST_DOT = $0001
    const ubyte RPB_ONE_DOT = 1
    const ubyte RPF_ONE_DOT = $0002
    const ubyte RPB_DBUFFER = 2
    const ubyte RPF_DBUFFER = $0004
    const ubyte RPB_AREAOUTLINE = 3
    const ubyte RPF_AREAOUTLINE = $0008
    const ubyte RPB_NOCROSSFILL = 5
    const ubyte RPF_NOCROSSFILL = $0020
    const ubyte RP_JAM1 = $0000
    const ubyte RP_JAM2 = $0001
    const ubyte RP_COMPLEMENT = $0002
    const ubyte RP_INVERSVID = $0004
    const ubyte RPB_TXSCALE = 0
    const ubyte RPF_TXSCALE = $0001
    const ubyte ONE_DOTn = $0001
    const ubyte ONE_DOT = $2
    const ubyte FRST_DOTn = $0000
    const ubyte FRST_DOT = $0001
    const long RPTAG_Font = $80000000
    const long RPTAG_APen = $80000002
    const long RPTAG_BPen = $80000003
    const long RPTAG_DrMd = $80000004
    const long RPTAG_OutLinePen = $80000005
    const long RPTAG_OutlinePen = $80000005
    const long RPTAG_WriteMask = $80000006
    const long RPTAG_MaxPen = $80000007
    const long RPTAG_DrawBounds = $80000008
    const long SPRITEA_Width = $81000000
    const long SPRITEA_XReplication = $81000002
    const long SPRITEA_YReplication = $81000004
    const long SPRITEA_OutputHeight = $81000006
    const long SPRITEA_Attached = $81000008
    const long SPRITEA_OldDataFormat = $8100000a
    const long GSTAG_SPRITE_NUM = $82000020
    const long GSTAG_ATTACHED = $82000022
    const long GSTAG_SOFTSPRITE = $82000024
    const long GSTAG_SCANDOUBLED = $83000000
    const ubyte FS_NORMAL = $0000
    const ubyte FSB_UNDERLINED = 0
    const ubyte FSF_UNDERLINED = $0001
    const ubyte FSB_BOLD = 1
    const ubyte FSF_BOLD = $0002
    const ubyte FSB_ITALIC = 2
    const ubyte FSF_ITALIC = $0004
    const ubyte FSB_EXTENDED = 3
    const ubyte FSF_EXTENDED = $0008
    const ubyte FSB_COLORFONT = 6
    const ubyte FSF_COLORFONT = $0040
    const ubyte FSB_TAGGED = 7
    const ubyte FSF_TAGGED = $0080
    const ubyte FPB_ROMFONT = 0
    const ubyte FPF_ROMFONT = $0001
    const ubyte FPB_DISKFONT = 1
    const ubyte FPF_DISKFONT = $0002
    const ubyte FPB_REVPATH = 2
    const ubyte FPF_REVPATH = $0004
    const ubyte FPB_TALLDOT = 3
    const ubyte FPF_TALLDOT = $0008
    const ubyte FPB_WIDEDOT = 4
    const ubyte FPF_WIDEDOT = $0010
    const ubyte FPB_PROPORTIONAL = 5
    const ubyte FPF_PROPORTIONAL = $0020
    const ubyte FPB_DESIGNED = 6
    const ubyte FPF_DESIGNED = $0040
    const ubyte FPB_REMOVED = 7
    const ubyte FPF_REMOVED = $0080
    const long TA_DeviceDPI = $80000001
    const uword MAXFONTMATCHWEIGHT = $7fff
    const ubyte TE0B_NOREMFONT = 0
    const ubyte TE0F_NOREMFONT = $0001
    const uword CT_COLORFONT = $0001
    const uword CT_GREYFONT = $0002
    const uword CT_ANTIALIAS = $0004
    const ubyte CTB_MAPCOLOR = 0
    const ubyte CTF_MAPCOLOR = $0001
    const long VTAG_END_CM = $00000000
    const long VTAG_CHROMAKEY_CLR = $80000000
    const long VTAG_CHROMAKEY_SET = $80000001
    const long VTAG_BITPLANEKEY_CLR = $80000002
    const long VTAG_BITPLANEKEY_SET = $80000003
    const long VTAG_BORDERBLANK_CLR = $80000004
    const long VTAG_BORDERBLANK_SET = $80000005
    const long VTAG_BORDERNOTRANS_CLR = $80000006
    const long VTAG_BORDERNOTRANS_SET = $80000007
    const long VTAG_CHROMA_PEN_CLR = $80000008
    const long VTAG_CHROMA_PEN_SET = $80000009
    const long VTAG_CHROMA_PLANE_SET = $8000000A
    const long VTAG_ATTACH_CM_SET = $8000000B
    const long VTAG_NEXTBUF_CM = $8000000C
    const long VTAG_BATCH_CM_CLR = $8000000D
    const long VTAG_BATCH_CM_SET = $8000000E
    const long VTAG_NORMAL_DISP_GET = $8000000F
    const long VTAG_NORMAL_DISP_SET = $80000010
    const long VTAG_COERCE_DISP_GET = $80000011
    const long VTAG_COERCE_DISP_SET = $80000012
    const long VTAG_VIEWPORTEXTRA_GET = $80000013
    const long VTAG_VIEWPORTEXTRA_SET = $80000014
    const long VTAG_CHROMAKEY_GET = $80000015
    const long VTAG_BITPLANEKEY_GET = $80000016
    const long VTAG_BORDERBLANK_GET = $80000017
    const long VTAG_BORDERNOTRANS_GET = $80000018
    const long VTAG_CHROMA_PEN_GET = $80000019
    const long VTAG_CHROMA_PLANE_GET = $8000001A
    const long VTAG_ATTACH_CM_GET = $8000001B
    const long VTAG_BATCH_CM_GET = $8000001C
    const long VTAG_BATCH_ITEMS_GET = $8000001D
    const long VTAG_BATCH_ITEMS_SET = $8000001E
    const long VTAG_BATCH_ITEMS_ADD = $8000001F
    const long VTAG_VPMODEID_GET = $80000020
    const long VTAG_VPMODEID_SET = $80000021
    const long VTAG_VPMODEID_CLR = $80000022
    const long VTAG_USERCLIP_GET = $80000023
    const long VTAG_USERCLIP_SET = $80000024
    const long VTAG_USERCLIP_CLR = $80000025
    const long VTAG_PF1_BASE_GET = $80000026
    const long VTAG_PF2_BASE_GET = $80000027
    const long VTAG_SPEVEN_BASE_GET = $80000028
    const long VTAG_SPODD_BASE_GET = $80000029
    const long VTAG_PF1_BASE_SET = $8000002a
    const long VTAG_PF2_BASE_SET = $8000002b
    const long VTAG_SPEVEN_BASE_SET = $8000002c
    const long VTAG_SPODD_BASE_SET = $8000002d
    const long VTAG_BORDERSPRITE_GET = $8000002e
    const long VTAG_BORDERSPRITE_SET = $8000002f
    const long VTAG_BORDERSPRITE_CLR = $80000030
    const long VTAG_SPRITERESN_SET = $80000031
    const long VTAG_SPRITERESN_GET = $80000032
    const long VTAG_PF1_TO_SPRITEPRI_SET = $80000033
    const long VTAG_PF1_TO_SPRITEPRI_GET = $80000034
    const long VTAG_PF2_TO_SPRITEPRI_SET = $80000035
    const long VTAG_PF2_TO_SPRITEPRI_GET = $80000036
    const long VTAG_IMMEDIATE = $80000037
    const long VTAG_FULLPALETTE_SET = $80000038
    const long VTAG_FULLPALETTE_GET = $80000039
    const long VTAG_FULLPALETTE_CLR = $8000003A
    const long VTAG_DEFSPRITERESN_SET = $8000003B
    const long VTAG_DEFSPRITERESN_GET = $8000003C
    const long VC_IntermediateCLUpdate = $80000080
    const long VC_IntermediateCLUpdate_Query = $80000081
    const long VC_NoColorPaletteLoad = $80000082
    const long VC_NoColorPaletteLoad_Query = $80000083
    const long VC_DUALPF_Disable = $80000084
    const long VC_DUALPF_Disable_Query = $80000085
    const ubyte GENLOCK_VIDEO = $2
    const ubyte V_LACE = $4
    const ubyte V_DOUBLESCAN = $8
    const ubyte V_SUPERHIRES = $20
    const ubyte V_PFBA = $40
    const ubyte V_EXTRA_HALFBRITE = $80
    const uword GENLOCK_AUDIO = $100
    const uword V_DUALPF = $400
    const uword V_HAM = $800
    const uword V_EXTENDED_MODE = $1000
    const uword V_VP_HIDE = $2000
    const uword V_SPRITES = $4000
    const uword V_HIRES = $8000
    const uword EXTEND_VSTRUCT = $1000
    const ubyte VPB_A2024 = 6
    const ubyte VPF_A2024 = $0040
    const ubyte VPB_TENHZ = 4
    const ubyte VPF_TENHZ = $0010
    const ubyte COLORMAP_TYPE_V1_2 = $00
    const ubyte COLORMAP_TYPE_V1_4 = $01
    const ubyte COLORMAP_TYPE_V39 = $02
    const ubyte COLORMAP_TRANSPARENCY = $01
    const ubyte COLORPLANE_TRANSPARENCY = $02
    const ubyte BORDER_BLANKING = $04
    const ubyte BORDER_NOTRANSPARENCY = $08
    const ubyte VIDEOCONTROL_BATCH = $10
    const ubyte USER_COPPER_CLIP = $20
    const ubyte BORDER_SPRITES = $40
    const ubyte CMB_CMTRANS = 0
    const ubyte CMF_CMTRANS = $0001
    const ubyte CMB_CPTRANS = 1
    const ubyte CMF_CPTRANS = $0002
    const ubyte CMB_BRDRBLNK = 2
    const ubyte CMF_BRDRBLNK = $0004
    const ubyte CMB_BRDNTRAN = 3
    const ubyte CMF_BRDNTRAN = $0008
    const ubyte CMB_BRDRSPRT = 6
    const ubyte CMF_BRDRSPRT = $0040
    const ubyte SPRITERESN_ECS = $0000
    const ubyte SPRITERESN_140NS = $0001
    const ubyte SPRITERESN_70NS = $0002
    const ubyte SPRITERESN_35NS = $0003
    const long SPRITERESN_DEFAULT = -1
    const ubyte CMAB_FULLPALETTE = 0
    const ubyte CMAF_FULLPALETTE = $0001
    const ubyte CMAB_NO_INTERMED_UPDATE = 1
    const ubyte CMAF_NO_INTERMED_UPDATE = $0002
    const ubyte CMAB_NO_COLOR_LOAD = 2
    const ubyte CMAF_NO_COLOR_LOAD = $0004
    const ubyte CMAB_DUALPF_DISABLE = 3
    const ubyte CMAF_DUALPF_DISABLE = $0008
    const long PRECISION_EXACT = -1
    const ubyte PRECISION_IMAGE = $0000
    const ubyte PRECISION_ICON = $0010
    const ubyte PRECISION_GUI = $0020
    const long OBP_Precision = $84000000
    const long OBP_FailIfBad = $84000001
    const ubyte PEN_EXCLUSIVE = $0001
    const ubyte PEN_NO_SETCOLOR = $0002
    const ubyte PENB_EXCLUSIVE = 0
    const ubyte PENF_EXCLUSIVE = $0001
    const ubyte PENB_NO_SETCOLOR = 1
    const ubyte PENF_NO_SETCOLOR = $0002
    const ubyte VPXB_FREE_ME = $0000
    const ubyte VPXF_FREE_ME = $0001
    const ubyte VPXB_VP_LAST = $0001
    const ubyte VPXF_VP_LAST = $0002
    const ubyte VPXB_STRADDLES_256 = $0004
    const ubyte VPXF_STRADDLES_256 = $0010
    const ubyte VPXB_STRADDLES_512 = $0005
    const ubyte VPXF_STRADDLES_512 = $0020
    const ubyte MVP_OK = $0000
    const ubyte MVP_NO_MEM = $0001
    const ubyte MVP_NO_VPE = $0002
    const ubyte MVP_NO_DSPINS = $0003
    const ubyte MVP_NO_DISPLAY = $0004
    const ubyte MVP_OFF_BOTTOM = $0005
    const ubyte MCOP_OK = $0000
    const ubyte MCOP_NO_MEM = $0001
    const ubyte MCOP_NOP = $0002
    const uword BMF_CHECKMASK = $0f80
    const uword BMF_CHECKVALUE = $0700
    const ubyte SETCHIPREV_A = $0001
    const ubyte SETCHIPREV_ECS = $0003
    const ubyte SETCHIPREV_AA = $000f
    const ubyte BANDWIDTH_1X = $0000
    const ubyte BANDWIDTH_2XNML = $0001
    const ubyte BANDWIDTH_2XDBL = $0002
    const ubyte BANDWIDTH_4X = $0003
    const long VGAEXTRALORESHAM_KEY = $00031804
    const long VGAEXTRALORESHAMLACE_KEY = $00031805
    const long VGAEXTRALORESEHB_KEY = $00031084
    const long VGAEXTRALORESEHBLACE_KEY = $00031085
    const long EURO72EXTRALORESHAM_KEY = $00061804
    const long EURO72EXTRALORESHAMLACE_KEY = $00061805
    const long EURO72EXTRALORESEHB_KEY = $00061084
    const long EURO72EXTRALORESEHBLACE_KEY = $00061085
    const uword MUST_FLAGS = $100e
    const ubyte COLORMAP_TYPE_V36 = $0001
}
;; End of auto-generated graphics_lib.sfd
