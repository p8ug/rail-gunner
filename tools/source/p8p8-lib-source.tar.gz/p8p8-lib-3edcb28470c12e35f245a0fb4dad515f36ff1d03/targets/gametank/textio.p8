; Prog8 definitions for the Text I/O and Screen routines for the GameTank
; Reference:  https://gametank.zone/manual/

%import syslib
%import conv

txt {

    %option no_symbol_prefixing, ignore_unused

    ; 24x20 with 5x6 font = 120 * 120 pixels.
    ; TVs cut off some of top & bottom apparently.
    ; Will need adjustment for real hardware.
    const ubyte DEFAULT_WIDTH = 24
    const ubyte DEFAULT_HEIGHT = 20
    ; 128 = print inverse character, 0 = normal
    ubyte inverse_mode = 0

    ; virtual screen coords/color
    ubyte vcol
    ubyte vrow
    ubyte vcolor = 7        ; text color white ish (TODO: const colors)
    ubyte bcolor = 0        ; text background color 
    ; temporary screen coords/color (for txt.set* mostly))
    ubyte tcol
    ubyte trow
    ubyte tcolor = 7        ; text color white ish (TODO: const colors)
    ubyte icolor = 0        ; background / inverse color (black normally)

sub  clear_screen() {
    ;sys.set_irqd()
    sys.memset(gametank.Screen, 24*20, 32)
    sys.memset(gametank.Color, 24*20, 0)
    sys.memset(gametank.SCREENRAM, 128*128, 0)
    ;sys.clear_irqd()
    vcolor = 7
}

sub  cls() {
    clear_screen()
}

sub  home() {
    plot(0,0)
}

sub nl() {
    chrout('\n')
;    vrow++
;    vcol=0
}

sub spc() {
    chrout(' ')
}

sub rvs_on() {
    inverse_mode = 1
}

sub rvs_off() {
    inverse_mode = 0
}

sub bell() {
;    chrout($fd)
}

;sub column(ubyte col) {
;    ; ---- set the cursor on the given column (starting with 0) on the current line
;    vcol = col
;}

inline asmsub column(ubyte col @A) {
    ; ---- set the cursor on the given column (starting with 0) on the current line
    %asm {{
        sta  txt.vcol
    }}
}

sub get_column() -> ubyte {
    return vcol
}

;sub row(ubyte rownum) {
;    ; ---- set the cursor on the given row (starting with 0) on the current line
;    vrow = rownum
;}

inline asmsub row(ubyte rownum @A) {
    ; ---- set the cursor on the given row (starting with 0) on the current line
    %asm {{
        sta  txt.vrow
    }}
}

sub get_row() -> ubyte {
    return vrow
}

asmsub  fill_screen (ubyte character @ A, ubyte color @ Y) clobbers(A)  {
    ; ---- fill the character screen with the given fill character and character color.
    ;      (assumes screen and color matrix are at their default addresses)
    ;      TODO

    %asm {{
        rts
    }}
}

asmsub  clear_screenchars (ubyte character @ A) clobbers(Y)  {
	; ---- clear the character screen with the given fill character (leaves colors)
	;      (assumes screen matrix is at the default address)
	; TODO
	%asm {{
	    rts
	}}
}

asmsub  clear_screencolors (ubyte color @ A) clobbers(Y)  {
	; ---- clear the character screen colors with the given color (leaves characters).
	;      (assumes color matrix is at the default address)
	; TODO
	%asm {{
	    rts
        }}
}

sub color (ubyte txtcol) {
    vcolor = txtcol
}

sub lowercase() {
    ; remove?
}

sub uppercase() {
    ; remove?
}

asmsub  scroll_left  (bool alsocolors @ Pc) clobbers(A, Y)  {
	; ---- scroll the whole screen 1 character to the left
	;      contents of the rightmost column are unchanged, you should clear/refill this yourself
	;      Carry flag determines if screen color data must be scrolled too
	;  TODO

	%asm {{
	    rts
        }}
}

asmsub  scroll_right  (bool alsocolors @ Pc) clobbers(A)  {
	; ---- scroll the whole screen 1 character to the right
	;      contents of the leftmost column are unchanged, you should clear/refill this yourself
	;      Carry flag determines if screen color data must be scrolled too
	; TODO
	%asm {{
	    rts
        }}
}

asmsub  scroll_up  (bool alsocolors @ Pc) clobbers(A)  {
	; ---- scroll the whole screen 1 character up
	;      contents of the bottom row are unchanged, you should refill/clear this yourself
	;      Carry flag determines if screen color data must be scrolled too
	; TODO
	%asm {{
            phy
            phx
            pha
            ; copy text memory
            lda  #<(gametank.Screen+24) ; source is row 1 not 0 (moving screen up one)
            sta  cx16.r0L
            lda  #>(gametank.Screen+24)
            sta  cx16.r0H
            lda  #<gametank.Screen      ; destination is row 0
            sta  cx16.r1L
            lda  #>gametank.Screen
            sta  cx16.r1H
            lda  #$c8                   ; 456 = $01c8
            ldy  #$01                   ; 24 cols & 19 rows
            jsr  sys.memcopy
            ; copy color memory
            lda  #<(gametank.Color+24) ; source is row 1 not 0 (moving colors up one)
            sta  cx16.r0L
            lda  #>(gametank.Color+24)
            sta  cx16.r0H
            lda  #<gametank.Color      ; destination is row 0
            sta  cx16.r1L
            lda  #>gametank.Color
            sta  cx16.r1H
            lda  #$c8                   ; 456 = $01c8
            ldy  #$01                   ; 24 cols & 19 rows
            jsr  sys.memcopy
            ; copy framebuffer memory
            lda  #<(gametank.SCREENRAM+1280) ; source is pixel row 10 (4 unused + 1 row x6)
            sta  cx16.r0L
            lda  #>(gametank.SCREENRAM+1280)
            sta  cx16.r0H
            lda  #<(gametank.SCREENRAM+512)  ; destination is pixel row 5
            sta  cx16.r1L
            lda  #>(gametank.SCREENRAM+512)
            sta  cx16.r1H
            lda  #$00                   ; 14592 = $3900
            ldy  #$39                   ; 128 pixel rows * 19 rows * 6 rows per character
            jsr  sys.memcopy
            ; clear bottom row of screen memory
            lda  #<(gametank.Screen+456) ; memory location to set
            sta  cx16.r0L
            lda  #>(gametank.Screen+456)
            sta  cx16.r0H
            lda  #<(12)  ; number of words to set
            sta  cx16.r1L
            lda  #>(12)
            sta  cx16.r1H
            lda  #$20                   ; set to space $20
            ldy  #$20                   ; set to space $20
            jsr  sys.memsetw
            ; clear bottom row of color memory
            lda  #<(gametank.Color+456) ; memory location to set
            sta  cx16.r0L
            lda  #>(gametank.Color+456)
            sta  cx16.r0H
            lda  #<(12)  ; number of words to set
            sta  cx16.r1L
            lda  #>(12)
            sta  cx16.r1H
            lda  txt.vcolor             ; set to current text color
            ldy  txt.vcolor             ; set to current text color 
            jsr  sys.memsetw
            ; clear bottom row of frame buffer
            lda  #<(gametank.SCREENRAM+15104) ; memory location to set
            sta  cx16.r0L
            lda  #>(gametank.SCREENRAM+15104)
            sta  cx16.r0H
            lda  #<(384)  ; number of words to set
            sta  cx16.r1L
            lda  #>(384)
            sta  cx16.r1H
            lda  #$00                   ; set to black $00
            ldy  #$00                   ; set to black $00
            jsr  sys.memsetw

            pla
            plx
            ply
	    rts
_copy:
            rts
        }}
}

asmsub  scroll_down  (bool alsocolors @ Pc) clobbers(A)  {
	; ---- scroll the whole screen 1 character down
	;      contents of the top row are unchanged, you should refill/clear this yourself
	;      Carry flag determines if screen color data must be scrolled too
	; TODO
	%asm {{
	    rts
        }}
}

asmsub chrout(ubyte char @A) {
        %asm {{
_charptr = cx16.r14
_colorptr = cx16.r15
            phy
            phx
            pha
            ; check for linefeed
            cmp  #$0d       ; linefeed
            beq  _crlf
            ; update virtual screen / color ram
            ldx txt.bcolor      ; load current background color
            stx txt.icolor      ; store to fb inverse/background color
            pha
            lda txt.vrow
            sta txt.trow
            asl a
            tay
            lda  setchr._screenrows,y
            sta  _charptr
            sta  _colorptr
            lda  setchr._screenrows+1,y
            sta  _charptr+1
            clc
            adc  #$02
            sta  _colorptr+1
            ; two pointers are ready
            ; ... calculate color
            ; ... turn on high bit of character if inverse mode?
            ; ... put character in destination
            ldy txt.vcol        ; load curent text column
            sty txt.tcol        ; store to fb draw column
            lda txt.vcolor      ; load current text color
            sta txt.tcolor      ; store to fb draw color
            sta (_colorptr),y   ; store to color ram
            pla                 ; restore a
            sta (_charptr), y
            ; after update text screen/color ram
            tax                 ; stash a briefly
            lda txt.inverse_mode
            beq +
            ; inverse (_charptr),y here by setting high bit
            ; maybe should toggle the high bit, but...
            ;lda (_charptr), y   ; load character from screen ram
            ;and #128            ; turn on high-bit to signal inverse
            ;sta (_charptr), y   ; store it back
            ; end of should inverse
            lda txt.vcolor      ; load normal text color
            sta txt.icolor      ; save to inverse/background
            lda txt.bcolor      ; load background
            sta txt.tcolor      ; save to normal text color
+           txa                 ; restore A
            jsr chrout_fb
            ; fix up vcol/vrow
            inc  vcol       ; increment vcol now that we have drawn
            lda  vcol       ; now check for overflow
            cmp  #24        ; wrapped past end of screen
            bcc  +          ; less than 24 we are done
_crlf:      inc  vrow       ; new vrow
            lda  #0
            sta  vcol
            lda  vrow       ; check if we are off bottom of screen
            cmp  #20
            bcc  +          ; less than 20 we are done
            lda  #19        ; should scroll but just stop at bottom
            sta  vrow
            sec             ; indicate we want to scroll color mem also
            jsr  scroll_up  ; scroll text/color/screen
+           pla
            plx
            ply
            rts
        }}
    }


    asmsub chrout_fb(ubyte char @A) {
        %asm {{
COLR = $f0
SPTR = $f1
FPTR = $f3
TEMP = $f5
FTMP = $f6
CHAR = $f7
            sta  CHAR       ; save character
            ; save X&Y (save all?)
            phy
            phx
            pha
            lda  #>MYFONT2  ; setup pointer to 5x6 font
            sta  FPTR+1
            lda  #<MYFONT2   ; should be $00
            sta  FPTR

            ; calculate screen memory pointer to text cell
            lda  txt.trow        ; add row offset to start of screen memory
            asl                 ; rows are 128 pixels * 6 rows so multiple by 3 pages.
            clc 
            adc  txt.trow       ; multiply 3rd time by adding again
            clc                 ; row offset is 128 pixel * 6 pixel (row width * font height)
            adc  #>gametank.SCREENRAM  ; high byte of screen memory start
            adc  #2             ; 4 row (4*128 or two pages) offset from top?
            sta  SPTR+1         ; store high byte 
            lda  txt.tcol       ; load column and multiply by 5 (font width)
            asl                 ; multiply by 2
            asl                 ; by 2 again
            clc
            adc  txt.tcol       ; multiply a 5th time by adding another copy
            adc  #4             ; 4 pixel offset on left
            sta  SPTR           ; low byte of screen pointer is column offset

            ; calculate character rom offset (6 bytes per character)
            ; should be 0-127 so first multiply can't overflow
            ; for reverse characters we might want to use 128-255
            ; or just invert?
            ; MYFONT2 must be page aligned
            lda  CHAR       ; restore requested character
            clc
            asl             ; multiply by 2
            bcc  +
            inc  FPTR+1     ; increment font pointer high byte
            clc
+           asl             ; multiply by 2 again
            bcc  +
            inc  FPTR+1     ; increment font pointer high byte
            clc
+           adc  CHAR       ; multiply 5th time by adding again
            bcc  +
            inc  FPTR+1     ; increment font pointer high byte
            clc
+           adc  CHAR       ; multiply 6th time by adding again
            bcc  +
            inc  FPTR+1     ; increment font pointer high byte
+           sta  FPTR       ; save font pointer low byte

            ; loop through 6 bytes of character rom
            ldy  #0         ; start at index zero
charloop:   sty  TEMP       ; save Y
            lda  (FPTR),y
            sta  FTMP       ; save font byte
            ; loop through 5 lower bits of font byte
            ; unrolled
            clc
            ldy  #0
            and  #%00010000 ; check bit 4
            beq  +          ; background pixel
            lda  txt.tcolor ; text color 
            bcc  ++
+           lda  txt.icolor ; background color
+           sta  (SPTR),y   ; set pixel
            ldy  #1         ; second bit -> pixel byte
            lda  FTMP       ; load font byte again
            and  #%00001000 ; check bit 3
            beq  +          ; background pixel
            lda  txt.tcolor ; text color
            bcc  ++
+           lda  txt.icolor ; background color
+           sta  (SPTR),y   ; set pixel
            ldy  #2         ; third bit -> pixel byte
            lda  FTMP       ; load font byte again
            and  #%00000100 ; check bit 2
            beq  +          ; background pixel
            lda  txt.tcolor ; text color
            bcc  ++
+           lda  txt.icolor ; background color
+           sta  (SPTR),y   ; set pixel
            ldy  #3         ; fourth bit -> pixel byte
            lda  FTMP       ; load font byte again
            and  #%00000010 ; check bit 1
            beq  +          ; background pixel
            lda  txt.tcolor ; text color
            bcc  ++
+           lda  txt.icolor ; background color
+           sta  (SPTR),y   ; set pixel
            ldy  #4         ; fifth bit -> pixel byte
            lda  FTMP       ; load font byte again
            and  #%00000001 ; check bit 0
            beq  +          ; background pixel
            lda  txt.tcolor ; text color
            bcc  ++
+           lda  txt.icolor ; background color
+           sta  (SPTR),y   ; set pixel

            ; add 128 to SPTR
            lda  SPTR       ; load low byte of screen pointer
            clc
            adc  #128        ; add one row width
            bcc  +
            inc  SPTR+1     ; increment high byte of screen pointer
+           sta  SPTR       ; save adjusted pointer

            ; next character rom byte
            ldy  TEMP       ; restore Y
            iny             ; increment char rom byte index
            cpy  #6
            bne  charloop   ; loop until y = 6

            ; should be done
            pla
            plx
            ply
            rts
        }}
    }
; needs to be page aligned for current draw system
%align $100 ; must be before label
MYFONT2:
%asmbinary "font5x6.bin", 2, 768

asmsub  print (str text @ AY) clobbers(A,Y)  {
	; ---- print zero terminated string from A/Y
	; note: the compiler contains an optimization that will replace
	;       a call to this subroutine with a string argument of just one char,
	;       by just one call to CHROUT of that single char.
	%asm {{
		sta  P8ZP_SCRATCH_W2
		sty  P8ZP_SCRATCH_W2+1
		ldy  #0
-		lda  (P8ZP_SCRATCH_W2),y
		beq  +
		jsr  chrout
		iny
		bne  -
+		rts
	}}
}

    sub print_bool(bool value) {
        if value
            txt.print("true")
        else
            txt.print("false")
    }

asmsub  print_ub0  (ubyte value @ A) clobbers(A,X,Y)  {
	; ---- print the ubyte in A in decimal form, with left padding 0s (3 positions total)
	%asm {{
		jsr  conv.internal_ubyte2decimal
		pha
		tya
		jsr  chrout
		txa
		jsr  chrout
		pla
		jmp  chrout
	}}
}

asmsub  print_ub  (ubyte value @ A) clobbers(A,X,Y)  {
	; ---- print the ubyte in A in decimal form, without left padding 0s
	%asm {{
		jsr  conv.internal_ubyte2decimal
_print_byte_digits
		pha
		cpy  #'0'
		beq  +
		tya
		jsr  chrout
		txa
		jsr  chrout
		jmp  _ones
+       cpx  #'0'
        beq  _ones
        txa
        jsr  chrout
_ones   pla
		jmp  chrout
	}}
}

asmsub  print_b  (byte value @ A) clobbers(A,X,Y)  {
	; ---- print the byte in A in decimal form, without left padding 0s
	%asm {{
		pha
		cmp  #0
		bpl  +
		lda  #'-'
		jsr  chrout
+		pla
		jsr  conv.internal_byte2decimal
		jmp  print_ub._print_byte_digits
	}}
}

asmsub  print_ubhex  (ubyte value @ A, bool prefix @ Pc) clobbers(A,X,Y)  {
	; ---- print the ubyte in A in hex form (if Carry is set, a radix prefix '$' is printed as well)
	%asm {{
		bcc  +
		pha
		lda  #'$'
		jsr  chrout
		pla
+		jsr  conv.internal_ubyte2hex
		jsr  chrout
		tya
		jmp  chrout
	}}
}

asmsub  print_ubbin  (ubyte value @ A, bool prefix @ Pc) clobbers(A,X,Y)  {
	; ---- print the ubyte in A in binary form (if Carry is set, a radix prefix '%' is printed as well)
	%asm {{
		sta  P8ZP_SCRATCH_B1
		bcc  +
		lda  #'%'
		jsr  chrout
+		ldy  #8
-		lda  #'0'
		asl  P8ZP_SCRATCH_B1
		bcc  +
		lda  #'1'
+		jsr  chrout
		dey
		bne  -
		rts
	}}
}

asmsub  print_uwbin  (uword value @ AY, bool prefix @ Pc) clobbers(A,X,Y)  {
	; ---- print the uword in A/Y in binary form (if Carry is set, a radix prefix '%' is printed as well)
	%asm {{
		pha
		tya
		jsr  print_ubbin
		pla
		clc
		jmp  print_ubbin
	}}
}

asmsub  print_uwhex  (uword value @ AY, bool prefix @ Pc) clobbers(A,X,Y)  {
	; ---- print the uword in A/Y in hexadecimal form (4 digits)
	;      (if Carry is set, a radix prefix '$' is printed as well)
	%asm {{
		pha
		tya
		jsr  print_ubhex
		pla
		clc
		jmp  print_ubhex
	}}
}

asmsub  print_uw0  (uword value @ AY) clobbers(A,X,Y)  {
	; ---- print the uword in A/Y in decimal form, with left padding 0s (5 positions total)
	%asm {{
		jsr  conv.internal_uword2decimal
		ldy  #0
-		lda  conv.internal_uword2decimal.decTenThousands,y
        beq  +
		jsr  chrout
		iny
		bne  -
+		rts
	}}
}

asmsub  print_uw  (uword value @ AY) clobbers(A,X,Y)  {
	; ---- print the uword in A/Y in decimal form, without left padding 0s
	%asm {{
		jsr  conv.internal_uword2decimal
		ldy  #0
-		lda  conv.internal_uword2decimal.decTenThousands,y
		beq  _allzero
		cmp  #'0'
		bne  _gotdigit
		iny
		bne  -

_gotdigit
		jsr  chrout
		iny
		lda  conv.internal_uword2decimal.decTenThousands,y
		bne  _gotdigit
		rts
_allzero
        lda  #'0'
        jmp  chrout
	}}
}

asmsub  print_w  (word value @ AY) clobbers(A,X,Y)  {
	; ---- print the (signed) word in A/Y in decimal form, without left padding 0's
	%asm {{
		cpy  #0
		bpl  +
		pha
		lda  #'-'
		jsr  chrout
		tya
		eor  #255
		tay
		pla
		eor  #255
		clc
		adc  #1
		bcc  +
		iny
+		jmp  print_uw
	}}
}

asmsub  input_chars  (^^ubyte buffer @ AY) clobbers(A) -> ubyte @ Y  {
	; ---- Input a string (max. 80 chars) from the keyboard. Returns length in Y. (string is terminated with a 0 byte as well)
	;      It assumes the keyboard is selected as I/O channel!
	;  TODO

	%asm {{
	    ldy  #0
	    rts
	}}
}

asmsub  setchr_fb  (ubyte col @X, ubyte row @Y, ubyte character @A) clobbers(A, Y)  {
	; ---- sets the character in the screen matrix at the given position
	%asm {{
                stx  txt.tcol
                sty  txt.trow
                ldx  txt.vcolor
                stx  txt.tcolor
                ldx  txt.bcolor
                stx  txt.icolor
                jmp  chrout_fb
	}}
}

asmsub  setchr  (ubyte col @X, ubyte row @Y, ubyte character @A) clobbers(A, Y)  {
	; ---- sets the character in the screen matrix at the given position
	%asm {{
                phy
		pha
		tya
		asl  a
		tay
		lda  _screenrows,y
		sta  P8ZP_SCRATCH_W1
		lda  _screenrows+1,y
		sta  P8ZP_SCRATCH_W1+1
		txa
		tay
		pla
		sta  (P8ZP_SCRATCH_W1),y
                ply
                jmp  setchr_fb

_screenrows	.word  gametank.Screen + range(0, DEFAULT_HEIGHT*DEFAULT_WIDTH, DEFAULT_WIDTH)
        ; !notreached!
	}}
}

asmsub  getchr  (ubyte col @A, ubyte row @Y) clobbers(Y) -> ubyte @ A {
	; ---- get the character in the screen matrix at the given location
	%asm  {{
		pha
		tya
		asl  a
		tay
		lda  setchr._screenrows,y
		sta  P8ZP_SCRATCH_W1
		lda  setchr._screenrows+1,y
		sta  P8ZP_SCRATCH_W1+1
		pla
		tay
		lda  (P8ZP_SCRATCH_W1),y
		rts
	}}
}

asmsub  setclr  (ubyte col @X, ubyte row @Y, ubyte color @A) clobbers(A, Y)  {
	; ---- set the color in A on the screen matrix at the given position
	%asm {{
                stx  txt.tcol
                sty  txt.trow
		pha
		tya
		asl  a
		tay
		lda  _colorrows,y
		sta  P8ZP_SCRATCH_W1
		lda  _colorrows+1,y
		sta  P8ZP_SCRATCH_W1+1
		txa
		tay
		pla
		sta  (P8ZP_SCRATCH_W1),y
                sta  txt.tcolor
                ldx  txt.bcolor
                stx  txt.icolor
                ; now get char at this row/col
                lda  txt.trow
                asl  a
                tay
                lda  setchr._screenrows,y
                sta  P8ZP_SCRATCH_W1
                lda  setchr._screenrows+1,y
                sta  P8ZP_SCRATCH_W1+1
                ldy  txt.tcol
                lda  (P8ZP_SCRATCH_W1),y
		jmp  chrout_fb

_colorrows	.word  gametank.Color + range(0, DEFAULT_HEIGHT*DEFAULT_WIDTH, DEFAULT_WIDTH)
        ; !notreached!
	}}
}

asmsub  getclr  (ubyte col @A, ubyte row @Y) clobbers(Y) -> ubyte @ A {
	; ---- get the color in the screen color matrix at the given location
	%asm  {{
		pha
		tya
		asl  a
		tay
		lda  setclr._colorrows,y
		sta  P8ZP_SCRATCH_W1
		lda  setclr._colorrows+1,y
		sta  P8ZP_SCRATCH_W1+1
		pla
		tay
        lda  (P8ZP_SCRATCH_W1),y
		rts
	}}
}

asmsub  setcc_fb  (ubyte col @X, ubyte row @Y, ubyte character @A, ubyte charcolor @R15) clobbers(A, Y)  {
	; ---- sets the character in the screen matrix at the given position
	%asm {{
                stx  txt.tcol
                sty  txt.trow
                ldx  cx16.r15L
                stx  txt.tcolor
                ldx  txt.bcolor
                stx  txt.icolor
                jmp  chrout_fb
	}}
}


sub  setcc  (ubyte col, ubyte row, ubyte character, ubyte charcolor)  {
	; ---- set char+color at the given position on the screen
	%asm {{
_charptr = P8ZP_SCRATCH_W1
_colorptr = P8ZP_SCRATCH_W2
		lda  row
		asl  a
		tay
		lda  setchr._screenrows,y
		sta  _charptr
		sta  _colorptr
		lda  setchr._screenrows+1,y
		sta  _charptr+1
		clc
		adc  #$02
		sta  _colorptr+1
		lda  character
		ldy  col
		sta  (_charptr),y
		lda  charcolor
		sta  (_colorptr),y
                sta  cx16.r15L
                ldx  col
                ldy  row
                lda  character
                jmp  setcc_fb
	}}
}

sub  plot(ubyte col, ubyte rownum) {
    column(col)
    row(rownum)
}

asmsub get_cursor() -> ubyte @X, ubyte @Y {
    %asm {{
        jsr  get_column
        pha
        jsr  get_row
        tay
        pla
        tax
        rts
    }}
}

asmsub waitkey() -> ubyte @A {
    %asm {{
        ;jmp  gametank.waitkey
        rts
    }}
}

asmsub width() clobbers(X,Y) -> ubyte @A {
    ; -- returns the text screen width (number of columns)
    %asm {{
        lda  #DEFAULT_WIDTH
        rts
    }}
}

asmsub height() clobbers(X, Y) -> ubyte @A {
    ; -- returns the text screen height (number of rows)
    %asm {{
        lda  #DEFAULT_HEIGHT
        rts
    }}
}

asmsub size() clobbers(A) -> ubyte @X, ubyte @Y {
    ; -- returns the text screen width in X and height in Y (number of columns and rows)
    %asm {{
        ldx  #DEFAULT_WIDTH
        ldy  #DEFAULT_HEIGHT
        rts
    }}
}

}
