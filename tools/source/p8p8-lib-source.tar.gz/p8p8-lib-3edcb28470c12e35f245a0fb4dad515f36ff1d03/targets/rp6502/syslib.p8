; Prog8 definitions for the Picocomputer 6502 aka RP6502.
; https://picocomputer.github.io/

%option no_symbol_prefixing, ignore_unused

cbm {
    ; waits to read a byte from the rx fifo.
    ; only handles keys, no other devices.
    asmsub CHRIN() -> ubyte @A {
        %asm {{
-           lda rp6502.ria_ready
            and #rp6502.RX_OK
            beq -               ; busy wait for a byte (keypress)
            lda rp6502.ria_rx   ; return byte from RX_FIFO
            clc                 ; clear carry when returning character
            rts
        }}
    }
    ; this will busy wait until it can transmit
    ; TODO: better solution?
    asmsub CHROUT(ubyte character @ A) {
        %asm {{
            pha
        -   lda $ffe0
            and #$80
            beq -
            pla
            sta $ffe1
            rts
        }}
    }

    ; check ria_ready if RX pending.
    asmsub GETIN() -> bool @Pc, ubyte @A {
        %asm {{
            lda rp6502.ria_ready
            and #rp6502.RX_OK
            beq +
            lda rp6502.ria_rx   ; return byte from RX_FIFO
            clc                 ; clear carry when returning character
            rts
+           sec                 ; set carry when no character returned
            lda #0              ; return zero if no key / character
            rts
        }}
    }
}

rp6502 {

    ; RP6502 registers
    &ubyte ria_ready    = $ffe0
    const ubyte TX_OK   = $80       ; bit 7 - TX FIFO not full. Ok to send.
    const ubyte RX_OK   = $40       ; bit 6 - RX FIFO has data ready.
    &ubyte ria_tx       = $ffe1     ; write byte to UART
    &ubyte ria_rx       = $ffe2     ; read byte from UART
    &ubyte ria_vsync    = $ffe3     ; increments ever 1/60th second when VGA connected
    &ubyte ria_rw0      = $ffe4     ; Read or write XRAM referenced by ADDR0
    &byte ria_step0     = $ffe5     ; Signed byte added to ADDR0 after each RW0 access.
    &uword ria_addr0    = $ffe6     ; & $ffe7 - XRAM address for RW0
    &ubyte ria_rw1      = $ffe8     ; Read or write XRAM referenced by ADDR1
    &byte ria_step1     = $ffe9     ; Signed byte added to ADDR1 after each RW1 access.
    &uword ria_addr1    = $ffea     ; & $ffeb - XRAM address for RW1
    &ubyte ria_xstack   = $ffec     ; 512 byte stack for passing call parameters
    &uword ria_errno    = $ffed     ; & $ffee - A uword version of errno below.
    &ubyte ria_errno_lo = $ffed     ; Low byte of errno.  All errors fit in this byte.
    &ubyte ria_errno_hi = $ffee     ; Allow errno to be an optional 16 bit int (uword)
    &ubyte ria_op       = $ffef     ; Write API operation id here to start kernel call.
    &ubyte ria_irq      = $fff0     ; Set bit 0 high to enable VSYNC interrupts.
                                    ; Verify source with VSYNC call.
                                    ; read or write this register to clear interrupt.
    &ubyte ria_return   = $fff1     ; Always $80 (BRA instruction) Block API call entry point.
    &ubyte ria_busy     = $fff2     ; Bit 7 high while operation is running.
    &ubyte ria_lda      = $fff3     ; Always $A9.
    &ubyte ria_a        = $fff4     ; Kernel register A.
    &ubyte ria_ldx      = $fff5     ; Always $A2.
    &ubyte ria_x        = $fff6     ; Kernel register X.
    &ubyte ria_rts      = $fff7     ; Always $60.
    &uword ria_sreg     = $fff8     ; & $fff9 - 32 bit extension to AX called AXSREG

    ; 6502 standard vectors.
    &uword  NMI_VEC         = $FFFA     ; 6502 nmi vector
    &uword  RESET_VEC       = $FFFC     ; 6502 reset vector
    &uword  IRQ_VEC         = $FFFE     ; 6502 interrupt vector

inline asmsub rombank(ubyte bank @A) {
    %asm {{
        .error "Banking is not supported."
    }}
}

inline asmsub rambank(ubyte bank @A) {
    ; -- set the ram bank
    %asm {{
        .error "Banking is not supported."
    }}
}

inline asmsub getrombank() -> ubyte @A {
    %asm {{
        .error "Banking is not supported."
    }}
}

inline asmsub getrambank() -> ubyte @A {
    %asm {{
        .error "Banking is not supported."
    }}
}

inline asmsub push_rombank(ubyte newbank @A) clobbers(Y) {
    %asm {{
        .error "Banking is not supported."
    }}
}

inline asmsub pop_rombank() {
    %asm {{
        .error "Banking is not supported."
    }}
}

inline asmsub push_rambank(ubyte newbank @A) clobbers(Y) {
    %asm {{
        .error "Banking is not supported."
    }}
}

inline asmsub pop_rambank() {
    %asm {{
        .error "Banking is not supported."
    }}
}

inline asmsub numbanks() -> ubyte @A {
    %asm {{
        .error "Banking is not supported."
    }}
}

    asmsub x16jsrfar() {
        %asm {{
            .error "Banking is not supported."
            ; !notreached!
        }}
    }
}

%import shared_sys_functions

sys {
    ; ------- lowlevel system routines --------

    const ubyte target = 5         ;  compilation target specifier.  255=virtual, 128=C128, 64=C64, 32=PET, 25=Foenix F256, 16=CommanderX16, 8=atari800XL, 7=Neo6502, 6=wdcsxb6, 5=rp6502

    const ubyte SIZEOF_BOOL  = sizeof(bool)
    const ubyte SIZEOF_BYTE  = sizeof(byte)
    const ubyte SIZEOF_UBYTE = sizeof(ubyte)
    const ubyte SIZEOF_WORD  = sizeof(word)
    const ubyte SIZEOF_UWORD = sizeof(uword)
    const ubyte SIZEOF_LONG  = sizeof(long)
    ;const ubyte SIZEOF_POINTER = sizeof(&sys.wait)
    const ubyte SIZEOF_FLOAT = 0    ; undefined, no floats supported
    const byte  MIN_BYTE     = -128
    const byte  MAX_BYTE     = 127
    const ubyte MIN_UBYTE    = 0
    const ubyte MAX_UBYTE    = 255
    const word  MIN_WORD     = -32768
    const word  MAX_WORD     = 32767
    const uword MIN_UWORD    = 0
    const uword MAX_UWORD    = 65535
    ; MIN_FLOAT and MAX_FLOAT are defined in the floats module if importec


    asmsub  reset_system()  {
        ; Soft-reset the system back to initial power-on status
        ; TODO
        %asm {{
            sei
            jmp  (rp6502.RESET_VEC)
        }}
    }

    sub wait(uword jiffies) {
        ; --- wait approximately the given number of jiffies (1/60th seconds)
        ;     TODO
    }

    asmsub waitvsync() clobbers(A) {
        ; --- busy wait till the next vsync has occurred (approximately), without depending on custom irq handling.
        ;     TODO
        %asm {{
            nop
            rts
        }}
    }

    asmsub internal_stringcopy(uword source @R0, uword target @AY) clobbers (A,Y) {
        ; Called when the compiler wants to assign a string value to another string.
        %asm {{
		sta  P8ZP_SCRATCH_W1
		sty  P8ZP_SCRATCH_W1+1
		lda  cx16.r0
		ldy  cx16.r0+1
		jmp  prog8_lib.strcpy
        }}
    }



    sub disable_caseswitch() {
        ; no-op
    }

    sub enable_caseswitch() {
        ; no-op
    }


    asmsub exit(ubyte returnvalue @A) {
        ; -- immediately exit the program with a return code in the A register
        %asm {{
            sta  p8_sys_startup.cleanup_at_exit._exitcode
            ldx  prog8_lib.orig_stackpointer
            txs
            jmp  p8_sys_startup.cleanup_at_exit
        }}
    }

    asmsub exit2(ubyte resulta @A, ubyte resultx @X, ubyte resulty @Y) {
        ; -- immediately exit the program with result values in the A, X and Y registers.
        %asm {{
            sta  p8_sys_startup.cleanup_at_exit._exitcode
            stx  p8_sys_startup.cleanup_at_exit._exitcodeX
            sty  p8_sys_startup.cleanup_at_exit._exitcodeY
            ldx  prog8_lib.orig_stackpointer
            txs
            jmp  p8_sys_startup.cleanup_at_exit
        }}
    }

    asmsub exit3(ubyte resulta @A, ubyte resultx @X, ubyte resulty @Y, bool carry @Pc) {
        ; -- immediately exit the program with result values in the A, X and Y registers, and the Carry flag in the status register.
        %asm {{
            sta  p8_sys_startup.cleanup_at_exit._exitcode
            lda  #0
            rol  a
            sta  p8_sys_startup.cleanup_at_exit._exitcarry
            stx  p8_sys_startup.cleanup_at_exit._exitcodeX
            sty  p8_sys_startup.cleanup_at_exit._exitcodeY
            ldx  prog8_lib.orig_stackpointer
            txs
            jmp  p8_sys_startup.cleanup_at_exit
        }}
    }

    inline asmsub push_returnaddress(uword address @XY) {
        %asm {{
            ; push like JSR would:  address-1,  MSB first then LSB
            cpx  #0
            bne  +
            dey
+           dex
            tya
            pha
            txa
            pha
        }}
    }

    asmsub get_as_returnaddress(uword address @XY) -> uword @AX {
        %asm {{
            ; return the address like JSR would push onto the stack:  address-1,  MSB first then LSB
            cpx  #0
            bne  +
            dey
+           dex
            tya
            rts
        }}
    }

    sub cpu_is_65816() -> bool {
        ; Returns true when you have a 65816 cpu, false when it's a 6502.
        %asm {{
			php
			clv
			.byte $e2, $ea  ; SEP #$ea, should be interpreted as 2 NOPs by 6502. 65c816 will set the Overflow flag.
			bvc +
			lda #1
			plp
			rts
+			lda #0
			plp
			rts
        }}
    }
}

cx16 {
; the sixteen virtual 16-bit registers in both normal unsigned mode and signed mode (s)
    &uword r0  = $0002
    &uword r1  = $0004
    &uword r2  = $0006
    &uword r3  = $0008
    &uword r4  = $000a
    &uword r5  = $000c
    &uword r6  = $000e
    &uword r7  = $0010
    &uword r8  = $0012
    &uword r9  = $0014
    &uword r10 = $0016
    &uword r11 = $0018
    &uword r12 = $001a
    &uword r13 = $001c
    &uword r14 = $001e
    &uword r15 = $0020

    ; signed word versions
    &word r0s  = $0002
    &word r1s  = $0004
    &word r2s  = $0006
    &word r3s  = $0008
    &word r4s  = $000a
    &word r5s  = $000c
    &word r6s  = $000e
    &word r7s  = $0010
    &word r8s  = $0012
    &word r9s  = $0014
    &word r10s = $0016
    &word r11s = $0018
    &word r12s = $001a
    &word r13s = $001c
    &word r14s = $001e
    &word r15s = $0020

    ; signed long versions
    &long r0r1sl = $0002
    &long r2r3sl = $0006
    &long r4r5sl = $000a
    &long r6r7sl = $000e
    &long r8r9sl = $0012
    &long r10r11sl = $0016
    &long r12r13sl = $001a
    &long r14r15sl = $001e

    ; ubyte versions (low and high bytes)
    &ubyte r0L  = $0002
    &ubyte r1L  = $0004
    &ubyte r2L  = $0006
    &ubyte r3L  = $0008
    &ubyte r4L  = $000a
    &ubyte r5L  = $000c
    &ubyte r6L  = $000e
    &ubyte r7L  = $0010
    &ubyte r8L  = $0012
    &ubyte r9L  = $0014
    &ubyte r10L = $0016
    &ubyte r11L = $0018
    &ubyte r12L = $001a
    &ubyte r13L = $001c
    &ubyte r14L = $001e
    &ubyte r15L = $0020

    &ubyte r0H  = $0003
    &ubyte r1H  = $0005
    &ubyte r2H  = $0007
    &ubyte r3H  = $0009
    &ubyte r4H  = $000b
    &ubyte r5H  = $000d
    &ubyte r6H  = $000f
    &ubyte r7H  = $0011
    &ubyte r8H  = $0013
    &ubyte r9H  = $0015
    &ubyte r10H = $0017
    &ubyte r11H = $0019
    &ubyte r12H = $001b
    &ubyte r13H = $001d
    &ubyte r14H = $001f
    &ubyte r15H = $0021

    ; signed byte versions (low and high bytes)
    &byte r0sL  = $0002
    &byte r1sL  = $0004
    &byte r2sL  = $0006
    &byte r3sL  = $0008
    &byte r4sL  = $000a
    &byte r5sL  = $000c
    &byte r6sL  = $000e
    &byte r7sL  = $0010
    &byte r8sL  = $0012
    &byte r9sL  = $0014
    &byte r10sL = $0016
    &byte r11sL = $0018
    &byte r12sL = $001a
    &byte r13sL = $001c
    &byte r14sL = $001e
    &byte r15sL = $0020

    &byte r0sH  = $0003
    &byte r1sH  = $0005
    &byte r2sH  = $0007
    &byte r3sH  = $0009
    &byte r4sH  = $000b
    &byte r5sH  = $000d
    &byte r6sH  = $000f
    &byte r7sH  = $0011
    &byte r8sH  = $0013
    &byte r9sH  = $0015
    &byte r10sH = $0017
    &byte r11sH = $0019
    &byte r12sH = $001b
    &byte r13sH = $001d
    &byte r14sH = $001f
    &byte r15sH = $0021

    ; boolean versions
    &bool r0bL  = $0002
    &bool r1bL  = $0004
    &bool r2bL  = $0006
    &bool r3bL  = $0008
    &bool r4bL  = $000a
    &bool r5bL  = $000c
    &bool r6bL  = $000e
    &bool r7bL  = $0010
    &bool r8bL  = $0012
    &bool r9bL  = $0014
    &bool r10bL = $0016
    &bool r11bL = $0018
    &bool r12bL = $001a
    &bool r13bL = $001c
    &bool r14bL = $001e
    &bool r15bL = $0020

    &bool r0bH  = $0003
    &bool r1bH  = $0005
    &bool r2bH  = $0007
    &bool r3bH  = $0009
    &bool r4bH  = $000b
    &bool r5bH  = $000d
    &bool r6bH  = $000f
    &bool r7bH  = $0011
    &bool r8bH  = $0013
    &bool r9bH  = $0015
    &bool r10bH = $0017
    &bool r11bH = $0019
    &bool r12bH = $001b
    &bool r13bH = $001d
    &bool r14bH = $001f
    &bool r15bH = $0021

    asmsub save_virtual_registers() clobbers(A,Y) {
        %asm {{
            ldy  #31
    -       lda  cx16.r0,y
            sta  _cx16_vreg_storage,y
            dey
            bpl  -
            rts

            .section BSS
    _cx16_vreg_storage
            .word ?,?,?,?,?,?,?,?
            .word ?,?,?,?,?,?,?,?
            .send BSS
            ; !notreached!
        }}
    }

    asmsub restore_virtual_registers() clobbers(A,Y) {
        %asm {{
            ldy  #31
    -       lda  save_virtual_registers._cx16_vreg_storage,y
            sta  cx16.r0,y
            dey
            bpl  -
            rts
        }}
    }
}

p8_sys_startup {
    ; program startup and shutdown machinery. Needs to reside in normal system ram.

    asmsub  init_system()  {
        ; Initializes the machine to a sane starting state.
        ; Called automatically by the loader program logic.
        %asm {{
            sei
            cld
            clc
            ; TODO reset screen mode etc etc?
            clv
            ; TODO what about IRQ handler?
            cli
            rts
        }}
    }

    asmsub  init_system_phase2()  {
        %asm {{
            rts     ; no phase 2 steps on the RP6502
        }}
    }

    asmsub  cleanup_at_exit() {
        ; executed when the main subroutine does rts
        %asm {{
            lda  _exitcarry
            lsr  a
            lda  _exitcode
            ldx  _exitcodeX
            ldy  _exitcodeY
            rts

            .section BSS
_exitcarry  .byte ?
_exitcode   .byte ?
_exitcodeX  .byte ?
_exitcodeY  .byte ?
            .send BSS

            ; !notreached!
        }}
    }

}
